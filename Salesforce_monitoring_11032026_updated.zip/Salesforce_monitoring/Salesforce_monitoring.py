import json
import re
import logging
import queue
import threading
import time
import urllib.parse
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import ttk, scrolledtext
import requests
from filelock import FileLock, Timeout
import subprocess
import os

# ============================================================================
# PRIVATE SETTINGS (.env)
# Passwords, keys and paths live in the ".env" file next to this script.
# ".env" is listed in .gitignore, so it is never uploaded to the repo.
# Edit .env anytime; restart this script to pick up changes.
# Order used: real Windows environment variable -> .env -> config.json -> default
# ============================================================================
def _load_env_file():
    base_dir = Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd()
    env_path = base_dir / ".env"
    if not env_path.exists():
        print(f"[CONFIG] No .env file found at {env_path}. Copy .env.example to .env and fill it in.")
        return None
    with open(env_path, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
                value = value[1:-1]
            os.environ.setdefault(key, value)
    return env_path

ENV_FILEPATH = _load_env_file()


def _setting(env_name, section=None, *json_keys, default=""):
    """Read a setting: environment/.env first, then config.json, then default."""
    value = os.environ.get(env_name, "").strip()
    if value:
        return value
    block = APP_CONFIG.get(section, {}) if section else APP_CONFIG
    for k in json_keys:
        if block.get(k):
            return str(block.get(k)).strip()
    return default


def _load_json_config():
    # 1) Paths set in .env (CONFIG_JSON_PATH first, then CREDENTIALS_JSON_PATH)
    candidates = []
    for env_name in ("CONFIG_JSON_PATH", "CREDENTIALS_JSON_PATH"):
        env_value = os.environ.get(env_name, "").strip()
        if env_value:
            env_path = Path(env_value)
            if env_path.exists():
                candidates.append(env_path)
            else:
                print(f"[CONFIG] {env_name} in .env points to a file that does not exist: {env_path}")

    # 2) Fallback: look for config.json / credentials.json in the usual folders near this script
    base_dir = Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd()
    search_dirs = [
        base_dir,
        base_dir.parent,
        base_dir.parent / "Solution Copy - Sequence Update(JAN)" / "RPA Workflow",
        Path.cwd(),
        Path.cwd() / "Solution Copy - Sequence Update(JAN)" / "RPA Workflow",
    ]
    for d in search_dirs:
        for fname in ["config.json", "credentials.json"]:
            candidates.append(d / fname)

    for cpath in candidates:
        if cpath.exists():
            try:
                with open(cpath, "r", encoding="utf-8-sig") as f:
                    data = json.load(f)
                    print(f"[CONFIG] Using settings file: {cpath}")
                    return data, cpath
            except Exception as e:
                print(f"[CONFIG] Could not read {cpath}: {e}")
                continue
    return {}, None

APP_CONFIG, CONFIG_FILEPATH = _load_json_config()

INSTANCE_URL = _setting("SF_INSTANCE_URL", "salesforce", "instanceUrl", "instance_url",
                        default="https://rsl-matrix--claimconv.sandbox.my.salesforce.com")

# OAuth 2.0 Credentials (set these in .env - never type them here)
CONSUMER_KEY = _setting("SF_CONSUMER_KEY", "salesforce", "consumerKey", "consumer_key")
CONSUMER_SECRET = _setting("SF_CONSUMER_SECRET", "salesforce", "consumerSecret", "consumer_secret")

SF_USERNAME = _setting("SF_USERNAME", "salesforce", "username") or str(APP_CONFIG.get("email", "") or "")
SF_PASSWORD = _setting("SF_PASSWORD", "salesforce", "password") or str(APP_CONFIG.get("password", "") or "")
SF_SECURITY_TOKEN = _setting("SF_SECURITY_TOKEN", "salesforce", "securityToken", "security_token")

_missing = [n for n, v in (("SF_CONSUMER_KEY", CONSUMER_KEY), ("SF_CONSUMER_SECRET", CONSUMER_SECRET),
                           ("SF_USERNAME", SF_USERNAME), ("SF_PASSWORD", SF_PASSWORD)) if not v]
if _missing:
    print("[CONFIG] Missing settings: " + ", ".join(_missing) + " -> add them to the .env file.")

# --- UIPATH EXECUTION PATHS (Auto-Resolved with Fallbacks) ---
def _resolve_paths():
    base_dir = Path(__file__).resolve().parent if '__file__' in globals() else Path.cwd()
    
    possible_project_dirs = [
        base_dir.parent / "Solution Copy - Sequence Update(JAN)" / "RPA Workflow",
        base_dir / ".." / "Solution Copy - Sequence Update(JAN)" / "RPA Workflow",
        base_dir.parent,
        Path(os.getcwd()) / "Solution Copy - Sequence Update(JAN)" / "RPA Workflow",
        Path(os.getcwd()) / "RPA Workflow"
    ]
    
    resolved_proj = None
    env_proj = os.environ.get("UIPATH_PROJECT_FILE", "").strip()
    if env_proj and Path(env_proj).exists():
        resolved_proj = Path(env_proj)
    
    # Folder 1: filesToLookupFolder (Primary)
    cfg_lookup1 = (
        os.environ.get("FILES_TO_LOOKUP_FOLDER", "").strip()
        or APP_CONFIG.get("paths", {}).get("filesToLookupFolder")
        or APP_CONFIG.get("paths", {}).get("files_to_lookup_folder")
    )
    if cfg_lookup1:
        folder1 = Path(cfg_lookup1)
    else:
        folder1 = (base_dir.parent / "Files_to_lookup").resolve()
        print(f"[CONFIG] FILES_TO_LOOKUP_FOLDER is not set in .env -> using {folder1}")

    # Folder 2: filesToLookupFolder2 (Secondary)
    cfg_lookup2 = (
        os.environ.get("FILES_TO_LOOKUP_FOLDER2", "").strip()
        or APP_CONFIG.get("paths", {}).get("filesToLookupFolder2")
        or APP_CONFIG.get("paths", {}).get("files_to_lookup_folder2")
        or APP_CONFIG.get("paths", {}).get("files_to_lookup_folder_2")
    )
    if cfg_lookup2:
        folder2 = Path(cfg_lookup2)
    else:
        folder2 = (base_dir.parent / "Files_to_lookup").resolve()

    lookup_folders = {
        "filesToLookupFolder": folder1,
        "filesToLookupFolder2": folder2,
    }

    for f_path in lookup_folders.values():
        try:
            f_path.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    for pdir in ([] if resolved_proj else possible_project_dirs):
        try:
            cand = (pdir / "project.json").resolve()
            if cand.exists():
                resolved_proj = cand
                break
        except Exception:
            continue
            
    if not resolved_proj:
        resolved_proj = base_dir.parent / "project.json"
        print(f"[CONFIG] UiPath project.json not found -> set UIPATH_PROJECT_FILE in .env (using {resolved_proj})")
    
    user_home = Path.home()
    possible_robots = [
        *(user_home.glob("AppData/Local/Programs/UiPathPlatform/Robot/*/UiRobot.exe")),
        user_home / "AppData" / "Local" / "Programs" / "UiPath" / "Studio" / "UiRobot.exe",
        user_home / "AppData" / "Local" / "Programs" / "UiPathPlatform" / "UiRobot.exe",
        Path(r"C:\Program Files\UiPath\Studio\UiRobot.exe"),
        Path(r"C:\Program Files (x86)\UiPath\Studio\UiRobot.exe"),
    ]
    resolved_robot = None
    env_robot = os.environ.get("UIPATH_ROBOT_EXE", "").strip()
    if env_robot and Path(env_robot).exists():
        possible_robots.insert(0, Path(env_robot))
    for rcand in possible_robots:
        try:
            if rcand.exists():
                resolved_robot = str(rcand.resolve())
                break
        except Exception:
            continue
            
    if not resolved_robot:
        resolved_robot = "UiRobot.exe"
        print("[CONFIG] UiRobot.exe not found -> set UIPATH_ROBOT_EXE in .env")
        
    return resolved_robot, str(resolved_proj), lookup_folders

UIPATH_ROBOT_EXE, UIPATH_PROJECT_FILE, LOOKUP_FOLDERS = _resolve_paths()

# Default primary folder: filesToLookupFolder2 if it exists, else filesToLookupFolder
LOOKUP_FOLDER = LOOKUP_FOLDERS.get("filesToLookupFolder2") if LOOKUP_FOLDERS.get("filesToLookupFolder2") and LOOKUP_FOLDERS.get("filesToLookupFolder2").exists() else LOOKUP_FOLDERS.get("filesToLookupFolder")
OUTPUT_JSON_FILE = str(LOOKUP_FOLDER / "file_completion_status.json")
POLL_INTERVAL_SECONDS = 2

# Optional session token from .env; if empty or expired the script logs in again automatically (OAuth).
current_access_token = os.environ.get("SF_ACCESS_TOKEN", "").strip()
HEADERS = {
    "Authorization": f"Bearer {current_access_token}",
    "Content-Type": "application/json",
}

log_queue = queue.Queue()


class QueueHandler(logging.Handler):
    def emit(self, record):
        msg = self.format(record)
        log_queue.put(msg)


logger = logging.getLogger("SalesforceMonitor")
logger.setLevel(logging.INFO)
queue_handler = QueueHandler()
queue_handler.setFormatter(
    logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
)
logger.addHandler(queue_handler)


def update_headers(token):
    global current_access_token, HEADERS
    current_access_token = token.strip()
    HEADERS["Authorization"] = f"Bearer {current_access_token}"


def refresh_token_via_oauth(username=None, password=None, security_token=None):
    user = username or SF_USERNAME
    pwd = password or SF_PASSWORD
    sec_token = security_token or SF_SECURITY_TOKEN

    if not user or not pwd:
        logger.warning("OAuth auth skipped: Salesforce Username/Password missing.")
        return False

    token_url = f"{INSTANCE_URL}/services/oauth2/token"
    
    # --- AUTOMATED CURL METHOD (client_credentials) ---
    payload = {
        "grant_type": "client_credentials",
        "client_id": CONSUMER_KEY,
        "client_secret": CONSUMER_SECRET,
        "username": user,
        "password": f"{pwd}{sec_token}",
    }

    try:
        response = requests.post(
            token_url,
            data=payload,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=10,
        )
        if response.status_code == 200:
            token_data = response.json()
            new_access_token = token_data.get("access_token")
            update_headers(new_access_token)
            logger.info("Successfully authenticated & generated new Access Token via OAuth 2.0 (client_credentials)!")
            return True
        else:
            logger.error(
                f"OAuth Token Request Failed ({response.status_code}): {response.text}"
            )
            return False
    except Exception as e:
        logger.error(f"Network error requesting OAuth token: {e}")
        return False

def format_sf_time(time_str):
    if not time_str: 
        return "N/A"
    try:
        dt = datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S.%f%z")
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return time_str

def calculate_duration(start_str, end_str):
    if not start_str or not end_str:
        return "In Progress / N/A"

    fmt = "%Y-%m-%dT%H:%M:%S.%f%z"
    try:
        start_dt = datetime.strptime(start_str, fmt)
        end_dt = datetime.strptime(end_str, fmt)
        duration = end_dt - start_dt
        total_seconds = int(duration.total_seconds())

        minutes, seconds = divmod(total_seconds, 60)
        hours, minutes = divmod(minutes, 60)

        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"
    except Exception:
        return "N/A"


def execute_soql_query(query, retry_attempt=True):
    encoded_query = urllib.parse.quote(query)
    url = f"{INSTANCE_URL}/services/data/v60.0/query/?q={encoded_query}"
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)

        if response.status_code in (401, 403) and retry_attempt:
            logger.warning("Session token rejected. Attempting OAuth renewal if configured...")
            if refresh_token_via_oauth():
                return execute_soql_query(query, retry_attempt=False)

        if response.status_code != 200:
            logger.error(
                f"SOQL Query Failed ({response.status_code}): {response.text}"
            )
            return []
        return response.json().get("records", [])
    except Exception as e:
        logger.error(f"Network error executing SOQL: {e}")
        return []


_DAILY_FILE_RE = re.compile(r"^files_uploaded_\d{8}\.json$", re.IGNORECASE)


def _daily_files(folder):
    """Only the one-file-per-day JSONs: files_uploaded_MMDDYYYY.json.
    OneDrive conflict copies (files_uploaded_MMDDYYYY-<PC name>-1.json) are ignored."""
    return [p for p in Path(folder).glob("files_uploaded_*.json") if _DAILY_FILE_RE.match(p.name)]


def read_json_records(filepath):
    if not filepath or not filepath.exists():
        return []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            elif isinstance(data, dict):
                return [data]
    except Exception as e:
        logger.error(f"Failed to read file {filepath.name}: {e}")
    return []


def load_all_target_files(specific_filepath=None, folder_path=None):
    if folder_path:
        target_folder = Path(folder_path)
    else:
        target_folder = LOOKUP_FOLDER
        if not target_folder.exists() or not target_folder.is_dir():
            for alt in LOOKUP_FOLDERS.values():
                if alt.exists() and alt.is_dir():
                    target_folder = alt
                    break

    if not target_folder.exists() or not target_folder.is_dir():
        return [], None

    if specific_filepath and Path(specific_filepath).exists():
        target_filepath = Path(specific_filepath)
    else:
        date_now = datetime.now().strftime("%m%d%Y")
        expected_filename = f"files_uploaded_{date_now}.json"
        target_filepath = target_folder / expected_filename

    target_files = []
    if target_filepath.exists():
        target_files = read_json_records(target_filepath)
    else:
        existing_files = sorted(
            _daily_files(target_folder),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )
        if existing_files:
            target_filepath = existing_files[0]
            target_files = read_json_records(target_filepath)
        else:
            return [], None

    return target_files, target_filepath


def _atomic_write_json(filepath, data, retries=25, delay=0.2):
    """Write JSON safely: write a temp file first, then swap it in.
    UiPath never sees a half-written / empty file this way."""
    filepath = Path(filepath)
    tmp_path = filepath.with_name(filepath.name + ".tmp")
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    last_err = None
    for _ in range(retries):
        try:
            os.replace(tmp_path, filepath)
            return
        except PermissionError as e:
            # The JSON is open in another program for a moment (e.g. UiPath reading it) -> try again
            last_err = e
            time.sleep(delay)
    logger.warning(f"Could not swap in {filepath.name} after {retries} tries ({last_err}); writing it directly instead.")
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    try:
        tmp_path.unlink()
    except OSError:
        pass


def update_source_input_file(filepath, updated_records):
    if not filepath or not filepath.exists():
        return

    lock_path = filepath.with_suffix(".json.lock")
    lock = FileLock(lock_path, timeout=10)

    try:
        with lock:
            latest_disk_data = []
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    latest_disk_data = json.load(f)
                    if isinstance(latest_disk_data, dict):
                        latest_disk_data = [latest_disk_data]
            except Exception as e:
                logger.error(f"Error reading source file during lock: {e}")
                return

            # Snapshot of what is on disk now, to skip the write when nothing changed.
            # (Rewriting the file every 2s keeps OneDrive busy and creates conflict copies.)
            before = json.dumps(latest_disk_data, sort_keys=True)

            updates_map = {
                item.get("file_name"): item for item in updated_records
            }

            merged_records = []
            for disk_item in latest_disk_data:
                file_name = disk_item.get("file_name")
                if file_name in updates_map:
                    upd = updates_map[file_name]
                    disk_item["file_type"] = upd.get("file_type", disk_item.get("file_type", "N/A"))
                    disk_item["dataset_id"] = upd.get("dataset_id", disk_item.get("dataset_id", "PENDING_ASSIGNMENT"))
                    disk_item["job_id"] = upd.get("job_id", disk_item.get("job_id", "N/A"))
                    disk_item["overall_status"] = upd.get("overall_status", disk_item.get("overall_status", "PENDING_DATASET_ASSIGNMENT"))
                    disk_item["duration"] = upd.get("duration", disk_item.get("duration", "N/A"))
                    disk_item["date_submitted"] = upd.get("date_submitted", disk_item.get("date_submitted", ""))
                    
                    # Ensured Start Time and End Time are permanently saved to the JSON file
                    disk_item["start_time"] = upd.get("start_time", disk_item.get("start_time", "N/A"))
                    disk_item["end_time"] = upd.get("end_time", disk_item.get("end_time", "N/A"))

                merged_records.append(disk_item)

            if json.dumps(merged_records, sort_keys=True) == before:
                return  # nothing changed -> do not touch the file
            _atomic_write_json(filepath, merged_records)

    except Timeout:
        logger.error(f"Could not acquire file lock for {filepath.name}. UiPath might be actively writing to it.")
    except Exception as e:
        logger.error(f"Failed to update input lookup file {filepath.name}: {e}")


def fetch_file_job_status(file_info):
    file_type = file_info.get("file_type", "N/A")
    file_name = file_info.get("file_name")
    date_submitted = file_info.get("date_submitted", "N/A")
    target_ds_id = file_info.get("dataset_id") or file_info.get("Id")

    if target_ds_id and target_ds_id not in ("PENDING_ASSIGNMENT", "N/A"):
        ds_query = f"""
            SELECT Id, Name, cvup2__JobId__c, CreatedBy.Name, CreatedDate 
            FROM cvup2__DataSet__c 
            WHERE Id = '{target_ds_id}'
        """
    else:
        ds_query = f"""
            SELECT Id, Name, cvup2__JobId__c, CreatedBy.Name, CreatedDate 
            FROM cvup2__DataSet__c 
            WHERE Name = '{file_name}' 
            ORDER BY CreatedDate DESC 
            LIMIT 1
        """

    ds_records = execute_soql_query(ds_query)

    if not ds_records:
        return {
            "file_type": file_type,
            "dataset_id": target_ds_id or "PENDING_ASSIGNMENT",
            "job_id": "N/A",
            "file_name": file_name,
            "date_submitted": date_submitted,
            "file_exists_in_sf": False,
            "overall_status": "FILE_NOT_FOUND",
            "uploaded_by": "N/A",
            "is_entirely_done": False,
            "total_jobs_detected": 0,
            "completed_jobs_count": 0,
            "duration": "N/A",
            "total_duration": "N/A",
            "start_time": "N/A",
            "end_time": "N/A",
            "jobs": [],
        }

    record = ds_records[0]
    dataset_id = record["Id"]
    root_job_id = record.get("cvup2__JobId__c")
    uploader_name = record.get("CreatedBy", {}).get("Name", "Unknown")

    if not root_job_id:
        return {
            "file_type": file_type,
            "dataset_id": dataset_id,
            "job_id": "PENDING_ASSIGNMENT",
            "file_name": file_name,
            "date_submitted": date_submitted,
            "file_exists_in_sf": True,
            "overall_status": "PENDING_JOB_ASSIGNMENT",
            "uploaded_by": uploader_name,
            "is_entirely_done": False,
            "total_jobs_detected": 0,
            "completed_jobs_count": 0,
            "duration": "Pending",
            "total_duration": "Pending",
            "start_time": "N/A",
            "end_time": "N/A",
            "jobs": [],
        }

    job_query = f"""
        SELECT Id, Status, JobType, TotalJobItems, JobItemsProcessed, NumberOfErrors, CreatedDate, CompletedDate, ParentJobId, ExtendedStatus 
        FROM AsyncApexJob 
        WHERE Id = '{root_job_id}' OR ParentJobId = '{root_job_id}' 
        ORDER BY CreatedDate ASC
    """
    job_records = execute_soql_query(job_query)

    parsed_jobs = []
    completed_jobs_count = 0
    has_failed_jobs = False
    start_times = []
    end_times = []

    for job in job_records:
        status = job["Status"]
        total_batches = job["TotalJobItems"]
        processed_batches = job["JobItemsProcessed"]
        errors = job["NumberOfErrors"]
        start_time = job.get("CreatedDate")
        end_time = job.get("CompletedDate")
        extended_status = job.get("ExtendedStatus")

        if start_time:
            start_times.append(start_time)
        if end_time:
            end_times.append(end_time)

        is_completed = status == "Completed" and errors == 0

        if is_completed:
            completed_jobs_count += 1
        elif status in ["Failed", "Aborted"] or errors > 0:
            has_failed_jobs = True

        parsed_jobs.append(
            {
                "dataset_id": dataset_id,
                "job_id": job["Id"],
                "parent_job_id": job.get("ParentJobId"),
                "is_completed": is_completed,
                "status": status,
                "batches_processed": f"{processed_batches}/{total_batches}",
                "errors": errors,
                "start_time": start_time,
                "completion_time": end_time,
                "extended_status": extended_status,
                "duration": calculate_duration(start_time, end_time),
            }
        )

    total_jobs = len(parsed_jobs)
    is_entirely_done = total_jobs > 0 and completed_jobs_count == total_jobs

    if has_failed_jobs:
        overall_status = "FAILED"
    elif is_entirely_done:
        overall_status = "COMPLETED"
    else:
        overall_status = "IN_PROGRESS"

    overall_duration = "In Progress / N/A"
    overall_start = "N/A"
    overall_end = "N/A"

    if start_times:
        earliest_start = min(start_times)
        overall_start = format_sf_time(earliest_start)
        
        if is_entirely_done and len(end_times) == len(job_records):
            latest_end = max(end_times)
            overall_end = format_sf_time(latest_end)
            overall_duration = calculate_duration(earliest_start, latest_end)
        elif end_times:
            latest_end = max(end_times)
            overall_end = format_sf_time(latest_end)
            overall_duration = f"{calculate_duration(earliest_start, latest_end)} (Running)"

    return {
        "file_type": file_type,
        "dataset_id": dataset_id,
        "job_id": root_job_id,
        "file_name": file_name,
        "date_submitted": date_submitted,
        "file_exists_in_sf": True,
        "overall_status": overall_status,
        "uploaded_by": uploader_name,
        "is_entirely_done": is_entirely_done,
        "total_jobs_detected": total_jobs,
        "completed_jobs_count": completed_jobs_count,
        "duration": overall_duration,
        "total_duration": overall_duration,
        "start_time": overall_start,
        "end_time": overall_end,
        "jobs": parsed_jobs,
    }


class SalesforceMonitorApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Salesforce Apex Job & UiPath File Monitor")
        self.geometry("1600x880")
        self.is_monitoring = False

        # Active folder key: default to filesToLookupFolder2 if it exists, else filesToLookupFolder
        if LOOKUP_FOLDERS.get("filesToLookupFolder2") and LOOKUP_FOLDERS.get("filesToLookupFolder2").exists():
            self.active_folder_key = "filesToLookupFolder2"
        else:
            self.active_folder_key = "filesToLookupFolder"

        self.currently_viewed_filepath = None
        self.active_monitored_filepath = None
        self.available_files_map = {}
        self.current_results_cache = []
        self.selected_file_name = None

        self.bot_was_running = False
        self.bot_start_time = None
        self.bot_pid = None
        self.recovery_attempts = 0
        self.max_recovery_retries = 3
        self.recovery_cooldown = 15
        self.last_recovery_time = 0
        self.is_recovering = False

        self._build_ui()
        self.refresh_date_file_list()
        self.after(100, self._process_log_queue)
        self.after(1000, self.check_uipath_health)
        self.after(200, self.start_monitoring)

    def get_active_folder_path(self):
        return LOOKUP_FOLDERS.get(self.active_folder_key, list(LOOKUP_FOLDERS.values())[0])

    def on_folder_switched(self):
        self.active_folder_key = self.folder_choice_var.get()
        f_path = self.get_active_folder_path()
        logger.info(f"Dashboard view switched to: {self.active_folder_key} ({f_path})")
        if hasattr(self, 'lbl_folder_path_display'):
            self.lbl_folder_path_display.config(text=f"📂 {self.active_folder_key}: {f_path}")
        self.refresh_date_file_list()

    def _build_ui(self):
        ctrl_frame = ttk.Frame(self, padding=8)
        ctrl_frame.pack(fill=tk.X)

        self.lbl_status = ttk.Label(
            ctrl_frame, text="⚡ Status: CONTINUOUS MONITORING ACTIVE", font=("Segoe UI", 10, "bold"), foreground="green"
        )
        self.lbl_status.pack(side=tk.LEFT, padx=10)

        self.lbl_viewing_indicator = ttk.Label(
            ctrl_frame, text="📄 Viewing: None", font=("Segoe UI", 9, "italic"), foreground="#555"
        )
        self.lbl_viewing_indicator.pack(side=tk.RIGHT, padx=10)

        bot_ctrl_frame = ttk.Frame(ctrl_frame)
        bot_ctrl_frame.pack(side=tk.RIGHT, padx=15)

        self.btn_run_bot = ttk.Button(
            bot_ctrl_frame,
            text="▶ Run Bot",
            command=self.run_uipath_bot
        )
        self.btn_run_bot.pack(side=tk.LEFT, padx=2)

        self.btn_stop_bot = ttk.Button(
            bot_ctrl_frame,
            text="⏹ Stop Bot",
            command=self.stop_uipath_bot
        )
        self.btn_stop_bot.pack(side=tk.LEFT, padx=2)

        self.btn_recover_bot = ttk.Button(
            bot_ctrl_frame,
            text="🔄 Recover / Restart",
            command=self.recover_uipath_bot
        )
        self.btn_recover_bot.pack(side=tk.LEFT, padx=2)

        self.auto_clear_var = tk.BooleanVar(value=True)
        self.chk_auto_clear = ttk.Checkbutton(
            bot_ctrl_frame,
            text="⚙ Auto-Kill Ghosts",
            variable=self.auto_clear_var
        )
        self.chk_auto_clear.pack(side=tk.LEFT, padx=6)

        self.auto_recovery_var = tk.BooleanVar(value=True)
        self.chk_auto_recover = ttk.Checkbutton(
            bot_ctrl_frame,
            text="🛡️ Auto-Recovery (Watchdog)",
            variable=self.auto_recovery_var
        )
        self.chk_auto_recover.pack(side=tk.LEFT, padx=6)

        self.lbl_uipath_status = ttk.Label(
            bot_ctrl_frame, text="🤖 UiPath: CHECKING...", font=("Segoe UI", 9, "bold")
        )
        self.lbl_uipath_status.pack(side=tk.LEFT, padx=5)

        health_frame = ttk.LabelFrame(self, text=" 🏥 UiPath Robot Health, Heartbeat & Watchdog Connection ", padding=6)
        health_frame.pack(fill=tk.X, padx=10, pady=2)

        health_grid = ttk.Frame(health_frame)
        health_grid.pack(fill=tk.X)

        self.lbl_health_badge = ttk.Label(
            health_grid, text="🟢 Health: CHECKING...", font=("Segoe UI", 9, "bold"), foreground="#005b9f"
        )
        self.lbl_health_badge.grid(row=0, column=0, padx=8, sticky=tk.W)

        self.lbl_process_metrics = ttk.Label(
            health_grid, text="📊 Process: PID: -- | RAM: -- MB | Uptime: --", font=("Segoe UI", 9)
        )
        self.lbl_process_metrics.grid(row=0, column=1, padx=8, sticky=tk.W)

        self.lbl_heartbeat = ttk.Label(
            health_grid, text="💓 Heartbeat: Checking...", font=("Segoe UI", 9)
        )
        self.lbl_heartbeat.grid(row=0, column=2, padx=8, sticky=tk.W)

        self.lbl_workload_status = ttk.Label(
            health_grid, text="📋 Workload: 0 Completed | 0 Pending", font=("Segoe UI", 9)
        )
        self.lbl_workload_status.grid(row=0, column=3, padx=8, sticky=tk.W)

        self.lbl_watchdog_status = ttk.Label(
            health_grid, text="🛡️ Watchdog: Armed (0 Restarts)", font=("Segoe UI", 9, "bold"), foreground="#155724"
        )
        self.lbl_watchdog_status.grid(row=0, column=4, padx=8, sticky=tk.E)

        health_grid.columnconfigure(1, weight=1)
        health_grid.columnconfigure(2, weight=1)
        health_grid.columnconfigure(3, weight=1)

        auth_frame = ttk.LabelFrame(self, text=" 🔐 Salesforce Credentials & Session ", padding=6)
        auth_frame.pack(fill=tk.X, padx=10, pady=2)

        ttk.Label(auth_frame, text="👤 Username:").grid(row=0, column=0, padx=2, sticky=tk.W)
        self.user_entry = ttk.Entry(auth_frame, width=28)
        self.user_entry.insert(0, SF_USERNAME)
        self.user_entry.grid(row=0, column=1, padx=4)

        ttk.Label(auth_frame, text="🔑 Password:").grid(row=0, column=2, padx=2, sticky=tk.W)
        self.pwd_entry = ttk.Entry(auth_frame, show="*", width=18)
        self.pwd_entry.insert(0, SF_PASSWORD)
        self.pwd_entry.grid(row=0, column=3, padx=4)

        ttk.Label(auth_frame, text="🛡️ Security Token:").grid(row=0, column=4, padx=2, sticky=tk.W)
        self.token_entry = ttk.Entry(auth_frame, show="*", width=22)
        self.token_entry.insert(0, SF_SECURITY_TOKEN)
        self.token_entry.grid(row=0, column=5, padx=4)

        btn_authenticate = ttk.Button(
            auth_frame, text="🔄 Authenticate / Refresh Token", command=self.apply_oauth_login
        )
        btn_authenticate.grid(row=0, column=6, padx=8)

        # MAIN HORIZONTAL SPLIT
        main_split = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        main_split.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # LEFT SIDEBAR
        sidebar_split = ttk.PanedWindow(main_split, orient=tk.VERTICAL)
        main_split.add(sidebar_split, weight=1)

        # 1. Date Picker
        sidebar_frame = ttk.LabelFrame(sidebar_split, text=" 📁 Files to Lookup (By Date) ", padding=5)
        sidebar_split.add(sidebar_frame, weight=1)

        side_btn_frame = ttk.Frame(sidebar_frame)
        side_btn_frame.pack(fill=tk.X, pady=2)

        btn_refresh_files = ttk.Button(
            side_btn_frame, text="🔄 Refresh Dates", command=self.refresh_date_file_list
        )
        btn_refresh_files.pack(fill=tk.X)

        self.tree_dates = ttk.Treeview(sidebar_frame, columns=("date", "filename"), show="headings", height=8)
        self.tree_dates.heading("date", text="📅 Run Date")
        self.tree_dates.heading("filename", text="📄 Batch File")
        self.tree_dates.column("date", width=105, anchor="center")
        self.tree_dates.column("filename", width=175)

        date_scroll = ttk.Scrollbar(sidebar_frame, orient=tk.VERTICAL, command=self.tree_dates.yview)
        self.tree_dates.configure(yscrollcommand=date_scroll.set)

        self.tree_dates.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, pady=4)
        date_scroll.pack(side=tk.RIGHT, fill=tk.Y, pady=4)
        self.tree_dates.bind("<<TreeviewSelect>>", self.on_date_selected)

        # 2. File / Dataset Drilldown & Logs
        self.detail_frame = ttk.LabelFrame(sidebar_split, text=" 🔍 File / Dataset Drilldown & Logs ", padding=5)
        sidebar_split.add(self.detail_frame, weight=2)

        self.lbl_selected_title = ttk.Label(
            self.detail_frame,
            text="Click any row in the table to inspect details",
            font=("Segoe UI", 9, "bold"),
            foreground="#005b9f",
            wraplength=310
        )
        self.lbl_selected_title.pack(anchor=tk.W, pady=2)

        self.detail_text = scrolledtext.ScrolledText(
            self.detail_frame, wrap=tk.WORD, height=18, font=("Consolas", 8), bg="#FDFDFD"
        )
        self.detail_text.pack(fill=tk.BOTH, expand=True, pady=2)

        # RIGHT MAIN PANEL
        right_split = ttk.PanedWindow(main_split, orient=tk.VERTICAL)
        main_split.add(right_split, weight=4)

        table_frame = ttk.LabelFrame(right_split, text=" 📊 Monitored Batch Files & Status ", padding=5)
        right_split.add(table_frame, weight=3)

        # Folder Selection Switcher Bar
        folder_bar = ttk.Frame(table_frame, padding=(2, 2, 2, 6))
        folder_bar.pack(fill=tk.X)

        ttk.Label(folder_bar, text="📂 Active Folder View:", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(4, 8))

        self.folder_choice_var = tk.StringVar(value=self.active_folder_key)

        self.rb_folder1 = ttk.Radiobutton(
            folder_bar,
            text="📁 filesToLookupFolder (Primary)",
            variable=self.folder_choice_var,
            value="filesToLookupFolder",
            command=self.on_folder_switched
        )
        self.rb_folder1.pack(side=tk.LEFT, padx=6)

        self.rb_folder2 = ttk.Radiobutton(
            folder_bar,
            text="📁 filesToLookupFolder2 (Secondary)",
            variable=self.folder_choice_var,
            value="filesToLookupFolder2",
            command=self.on_folder_switched
        )
        self.rb_folder2.pack(side=tk.LEFT, padx=6)

        self.lbl_folder_path_display = ttk.Label(
            folder_bar,
            text=f"📂 {self.active_folder_key}: {self.get_active_folder_path()}",
            font=("Segoe UI", 8, "italic"),
            foreground="#555"
        )
        self.lbl_folder_path_display.pack(side=tk.RIGHT, padx=6)

        columns = (
            "file_type",
            "dataset_id",
            "job_id",
            "file_name",
            "date_submitted",
            "uploaded_by",
            "overall_status",
            "jobs_progress",
            "start_time",
            "end_time",
            "duration",
        )
        
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        tree_yscroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        tree_xscroll = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=tree_yscroll.set, xscrollcommand=tree_xscroll.set)

        self.tree.heading("file_type", text="📁 File Type")
        self.tree.heading("dataset_id", text="🆔 Data Set ID")
        self.tree.heading("job_id", text="⚡ Job ID")
        self.tree.heading("file_name", text="📄 File Name")
        self.tree.heading("date_submitted", text="📅 Date Submitted")
        self.tree.heading("uploaded_by", text="👤 Uploaded By")
        self.tree.heading("overall_status", text="📌 Overall Status")
        self.tree.heading("jobs_progress", text="✅ Completed Jobs")
        self.tree.heading("start_time", text="▶ Start Time")
        self.tree.heading("end_time", text="⏹ End Time")
        self.tree.heading("duration", text="⏱ Duration")

        self.tree.column("file_type", width=105, anchor="center")
        self.tree.column("dataset_id", width=160, anchor="center")
        self.tree.column("job_id", width=160, anchor="center")
        self.tree.column("file_name", width=250)
        self.tree.column("date_submitted", width=110, anchor="center")
        self.tree.column("uploaded_by", width=110, anchor="center")
        self.tree.column("overall_status", width=140, anchor="center")
        self.tree.column("jobs_progress", width=110, anchor="center")
        self.tree.column("start_time", width=150, anchor="center")
        self.tree.column("end_time", width=150, anchor="center")
        self.tree.column("duration", width=120, anchor="center")

        self.tree.tag_configure("COMPLETED", background="#D4EDDA", foreground="#155724")
        self.tree.tag_configure("IN_PROGRESS", background="#FFF3CD", foreground="#856404")
        self.tree.tag_configure("FILE_NOT_FOUND", background="#F8D7DA", foreground="#721C24")
        self.tree.tag_configure("FAILED", background="#F8D7DA", foreground="#721C24")
        self.tree.tag_configure("PENDING_JOB_ASSIGNMENT", background="#E2E3E5", foreground="#383D41")

        tree_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_yscroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree.bind("<<TreeviewSelect>>", self.on_row_selected)

        log_frame = ttk.LabelFrame(right_split, text=" 📜 Live System & SOQL Query Logs ", padding=5)
        right_split.add(log_frame, weight=2)

        self.log_text = scrolledtext.ScrolledText(log_frame, wrap=tk.WORD, height=10, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)

    def on_row_selected(self, event):
        """Immediately retrieves recorded logs and sub-job details when a user clicks any row."""
        selected = self.tree.selection()
        if not selected:
            return

        values = self.tree.item(selected[0], "values")
        if not values or len(values) < 4:
            return

        dataset_id = values[1]
        job_id = values[2]
        file_name = values[3]

        self.selected_file_name = file_name
        self.lbl_selected_title.config(text=f"🔄 Fetching recorded logs for {file_name}...")

        # Asynchronously fetch live logs from Salesforce so the UI doesn't freeze
        threading.Thread(
            target=self._fetch_and_render_on_demand,
            args=(dataset_id, job_id, file_name),
            daemon=True
        ).start()

    def _fetch_and_render_on_demand(self, dataset_id, root_job_id, file_name):
        """Pulls recorded jobs and checks for dataset error logs."""
        logger.info(f"Retrieving recorded logs for: {file_name} (Job: {root_job_id})")

        job_records = []
        if root_job_id and root_job_id not in ("N/A", "PENDING_ASSIGNMENT"):
            job_query = f"""
                SELECT Id, Status, JobType, TotalJobItems, JobItemsProcessed, NumberOfErrors, CreatedDate, CompletedDate, ParentJobId, ExtendedStatus 
                FROM AsyncApexJob 
                WHERE Id = '{root_job_id}' OR ParentJobId = '{root_job_id}' 
                ORDER BY CreatedDate ASC
            """
            job_records = execute_soql_query(job_query)

        # Also inspect the DataSet record itself for parser errors
        ds_error_text = None
        if dataset_id and dataset_id not in ("N/A", "PENDING_ASSIGNMENT"):
            try:
                ds_obj_url = f"{INSTANCE_URL}/services/data/v60.0/sobjects/cvup2__DataSet__c/{dataset_id}"
                resp = requests.get(ds_obj_url, headers=HEADERS, timeout=10)
                if resp.status_code == 200:
                    data = resp.json()
                    for k, v in data.items():
                        if v and any(term in k.lower() for term in ["error", "status", "message", "log", "exception"]):
                            if "error" in str(v).lower() or "exception" in str(v).lower() or "column" in str(v).lower():
                                ds_error_text = f"{k}: {v}"
                                break
            except Exception as e:
                logger.error(f"Error checking dataset error logs: {e}")

        parsed_jobs = []
        for j in job_records:
            parsed_jobs.append({
                "job_id": j["Id"],
                "status": j["Status"],
                "batches": f"{j.get('JobItemsProcessed', 0)}/{j.get('TotalJobItems', 0)}",
                "errors": j.get("NumberOfErrors", 0),
                "duration": calculate_duration(j.get("CreatedDate"), j.get("CompletedDate")),
                "start_time": j.get("CreatedDate", "N/A"),
                "completion_time": j.get("CompletedDate", "N/A"),
                "extended_status": j.get("ExtendedStatus"),
                "is_completed": (j["Status"] == "Completed" and j.get("NumberOfErrors", 0) == 0)
            })

        # Update cache in memory
        matched_item = next((item for item in self.current_results_cache if item.get("file_name") == file_name), None)
        if matched_item:
            matched_item["jobs"] = parsed_jobs
            if ds_error_text:
                matched_item["dataset_error"] = ds_error_text

        self.after(0, lambda: self.render_drilldown_view(file_name, dataset_id, root_job_id, parsed_jobs, ds_error_text))

    def render_drilldown_view(self, file_name, dataset_id, root_job_id, jobs, ds_error):
        """Displays formatted logs in the sidebar text box."""
        self.lbl_selected_title.config(
            text=f"📄 {file_name}\nJob: {root_job_id}"
        )
        self.detail_text.delete("1.0", tk.END)

        header = (
            f"=========================================\n"
            f"📄 File:       {file_name}\n"
            f"🆔 DataSet ID: {dataset_id}\n"
            f"⚡ Root Job:   {root_job_id}\n"
            f"📅 Timestamp:  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"=========================================\n\n"
        )
        self.detail_text.insert(tk.END, header)

        if ds_error:
            self.detail_text.insert(
                tk.END,
                f"🛑 PARSER / UPLOAD ERROR DETECTED:\n{ds_error}\n\n"
                f"-----------------------------------------\n"
            )

        if not jobs:
            self.detail_text.insert(tk.END, "⚠️ No AsyncApexJobs records returned from Salesforce.\n")
            return

        self.detail_text.insert(tk.END, f"--- RECORDED BATCH LOGS ({len(jobs)} items) ---\n\n")
        for idx, j in enumerate(jobs, 1):
            badge = "✅" if j["is_completed"] else ("❌" if j["status"] in ["Failed", "Aborted"] or j["errors"] > 0 else "⏳")

            job_log = (
                f"{badge} Batch #{idx} [{j['job_id']}]\n"
                f"   Status:    {j['status']}\n"
                f"   Batches:   {j['batches']}\n"
                f"   Errors:    {j['errors']}\n"
                f"   Duration:  {j['duration']}\n"
                f"   Started:   {j['start_time']}\n"
                f"   Finished:  {j['completion_time']}\n"
            )

            if j.get("extended_status"):
                job_log += f"   🛑 Failure Details:\n      {j['extended_status']}\n"

            job_log += "-----------------------------------------\n"
            self.detail_text.insert(tk.END, job_log)

    def run_uipath_bot(self):
        if not os.path.exists(UIPATH_ROBOT_EXE):
            logger.error(f"Cannot run bot: UiRobot.exe not found at {UIPATH_ROBOT_EXE}")
            return

        if not os.path.exists(UIPATH_PROJECT_FILE):
            logger.error(f"Cannot run bot: project.json not found at {UIPATH_PROJECT_FILE}")
            return

        try:
            logger.info("Sending command to start UiPath Bot...")
            cmd = f'"{UIPATH_ROBOT_EXE}" execute --file "{UIPATH_PROJECT_FILE}"'
            logger.info(f"Executing: {cmd}")

            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                startupinfo=startupinfo
            )

            # Mark active bot execution session
            self.bot_was_running = True
            self.bot_start_time = time.time()

            def check_output():
                stdout, stderr = process.communicate()
                exit_code = process.returncode
                if stdout.strip():
                    logger.info(f"UiPath Output: {stdout.strip()}")
                if stderr.strip():
                    logger.error(f"UiPath Error: {stderr.strip()}")
                if exit_code != 0 and exit_code is not None:
                    logger.warning(f"UiPath process exited with code: {exit_code}")

            threading.Thread(target=check_output, daemon=True).start()
            logger.info("Bot execution requested successfully.")

        except Exception as e:
            logger.error(f"Failed to launch UiPath Bot: {e}")

    def stop_uipath_bot(self):
        logger.info("User requested to forcefully stop the UiPath bot.")
        self.bot_was_running = False
        self.bot_start_time = None
        self.kill_ghost_executor()

    def recover_uipath_bot(self):
        """Manual one-click recovery initiated by user."""
        logger.info("User requested manual Bot Recovery / Restart.")
        self.recovery_attempts = 0  
        self.trigger_auto_recovery(reason="Manual User Recovery Request")

    def trigger_auto_recovery(self, reason="Crash Detected"):
        """Executes the automated recovery sequence: cleans ghost processes, clears locks, and relaunches."""
        if self.is_recovering:
            return
        self.is_recovering = True
        self.recovery_attempts += 1
        self.last_recovery_time = time.time()

        logger.warning(f"🚨 AUTO-RECOVERY TRIGGERED ({reason}) - Attempt {self.recovery_attempts}/{self.max_recovery_retries}")
        self.lbl_health_badge.config(text=f"🔄 RECOVERING ({self.recovery_attempts}/{self.max_recovery_retries})...", foreground="orange")
        self.lbl_watchdog_status.config(text=f"🛡️ Watchdog: Recovering ({self.recovery_attempts}/{self.max_recovery_retries})", foreground="orange")

        def _recovery_worker():
            try:
                logger.info("[AUTO-RECOVERY] Step 1/3: Clearing any lingering/zombie executor processes...")
                self.kill_ghost_executor()

                logger.info("[AUTO-RECOVERY] Step 2/3: Checking and clearing stale file locks...")
                for lfolder in LOOKUP_FOLDERS.values():
                    if lfolder.exists():
                        for lock_file in lfolder.glob("*.lock"):
                            try:
                                if time.time() - lock_file.stat().st_mtime > 5:
                                    lock_file.unlink(missing_ok=True)
                                    logger.info(f"[AUTO-RECOVERY] Cleared stale lock in {lfolder.name}: {lock_file.name}")
                            except Exception:
                                pass

                time.sleep(5)

                logger.info(f"[AUTO-RECOVERY] Step 3/3: Relaunching UiPath Bot (Attempt {self.recovery_attempts}/{self.max_recovery_retries})...")
                self.run_uipath_bot()
                logger.info("[AUTO-RECOVERY] ✅ Bot restarted successfully! Resuming pending workflow files...")

            except Exception as e:
                logger.error(f"[AUTO-RECOVERY] Error during recovery sequence: {e}")
            finally:
                self.is_recovering = False

        threading.Thread(target=_recovery_worker, daemon=True).start()

    def kill_ghost_executor(self):
        try:
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

            subprocess.run(["taskkill", "/F", "/IM", "UiPath.Executor.exe"], startupinfo=startupinfo, stderr=subprocess.DEVNULL)
            subprocess.run(["taskkill", "/F", "/IM", "UiPath.Executor32.exe"], startupinfo=startupinfo, stderr=subprocess.DEVNULL)

            logger.info("Bot/Ghost processes successfully cleared.")
        except Exception as e:
            logger.error(f"Failed to kill process: {e}")

    def check_uipath_running(self):
        self.check_uipath_health()

    def check_uipath_health(self):
        try:
            ps_code = """
            $res = @{
                executors = @(Get-CimInstance Win32_Process -Filter "Name like 'UiPath.Executor%'" -ErrorAction SilentlyContinue | Select-Object ProcessId, CommandLine, WorkingSetSize);
                hosts = @(Get-CimInstance Win32_Process -Filter "Name like 'UiPath.Studio%' or Name like 'UiRobot%' or Name like 'UiPath.Connected%' or Name like 'UiPath.Robot%'" -ErrorAction SilentlyContinue | Select-Object ProcessId, Name);
                edge = @(Get-Process msedge -ErrorAction SilentlyContinue | Select-Object -First 1 Id);
            }
            $res | ConvertTo-Json -Compress
            """
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            output = subprocess.check_output(
                ["powershell", "-NoProfile", "-Command", ps_code],
                shell=False,
                text=True,
                startupinfo=startupinfo,
                timeout=8
            )
            data = json.loads(output) if output.strip() else {}
        except Exception:
            data = {}

        executors = data.get("executors", [])
        if isinstance(executors, dict):
            executors = [executors]
        hosts = data.get("hosts", [])
        if isinstance(hosts, dict):
            hosts = [hosts]
        has_edge = bool(data.get("edge"))

        target_project_name = "RPA Workflow"
        target_executor = None
        other_executor = None

        for ex in executors:
            cmdline = str(ex.get("CommandLine", ""))
            if target_project_name.lower() in cmdline.lower():
                target_executor = ex
                break
            elif "UiPath.Executor" in cmdline or ex.get("ProcessId"):
                other_executor = ex

        active_executor = target_executor or other_executor

        target_file_list, source_filepath = load_all_target_files(folder_path=self.get_active_folder_path())
        pending_count = 0
        completed_count = 0
        failed_count = 0
        current_file_active = None

        for f in target_file_list:
            st = str(f.get("overall_status", "")).upper()
            if st == "COMPLETED":
                completed_count += 1
            elif st == "FAILED":
                failed_count += 1
            else:
                pending_count += 1
                if not current_file_active:
                    current_file_active = f.get("file_name")

        heartbeat_sec = None
        heartbeat_str = "No Activity Recorded"
        heartbeat_color = "#555"

        if source_filepath and source_filepath.exists():
            try:
                mtime = source_filepath.stat().st_mtime
                heartbeat_sec = int(time.time() - mtime)
                if heartbeat_sec < 15:
                    heartbeat_str = f"💓 Live ({heartbeat_sec}s ago)"
                    heartbeat_color = "green"
                elif heartbeat_sec < 60:
                    heartbeat_str = f"💓 Active ({heartbeat_sec}s ago)"
                    heartbeat_color = "#005b9f"
                elif heartbeat_sec < 300:
                    heartbeat_str = f"💓 Idle ({heartbeat_sec // 60}m {heartbeat_sec % 60}s ago)"
                    heartbeat_color = "#d48a00"
                else:
                    heartbeat_str = f"⚠️ Stale ({heartbeat_sec // 60}m ago)"
                    heartbeat_color = "red"
            except Exception:
                pass

        if active_executor:
            pid = active_executor.get("ProcessId")
            ws_bytes = active_executor.get("WorkingSetSize") or 0
            ram_mb = round(ws_bytes / (1024 * 1024), 1) if ws_bytes else 0

            if not self.bot_was_running:
                self.bot_was_running = True
                self.bot_start_time = time.time()
                self.bot_pid = pid
                logger.info(f"UiPath Bot detected running (PID: {pid}, Memory: {ram_mb} MB).")

            uptime_sec = int(time.time() - self.bot_start_time) if self.bot_start_time else 0
            up_m, up_s = divmod(uptime_sec, 60)
            up_h, up_m = divmod(up_m, 60)
            uptime_str = f"{up_h}h {up_m}m {up_s}s" if up_h > 0 else f"{up_m}m {up_s}s"

            is_frozen = (uptime_sec > 600 and heartbeat_sec and heartbeat_sec > 600 and pending_count > 0)

            if is_frozen:
                status_text = f"⚠️ UiPath: HUNG / UNRESPONSIVE (No heartbeat in {heartbeat_sec // 60}m)"
                status_color = "red"
                health_text = "🚨 Health: UNRESPONSIVE (FROZEN)"
                health_color = "red"

                if self.auto_recovery_var.get() and (time.time() - self.last_recovery_time > 60):
                    self.trigger_auto_recovery(reason=f"Executor hung for {heartbeat_sec}s with {pending_count} pending files")
            elif target_executor:
                status_text = f"🤖 UiPath: EXECUTING ({target_project_name} | PID {pid})"
                status_color = "green"
                health_text = "🟢 Health: HEALTHY (EXECUTING)"
                health_color = "green"
            else:
                if self.auto_clear_var.get():
                    status_text = "🤖 AUTO-CLEARING GHOST..."
                    status_color = "orange"
                    self.kill_ghost_executor()
                else:
                    status_text = f"🤖 UiPath: EXECUTING (Other | PID {pid})"
                    status_color = "#d48a00"
                health_text = "🟡 Health: EXECUTING (OTHER)"
                health_color = "#d48a00"

            metrics_text = f"📊 Process: PID: {pid} | RAM: {ram_mb} MB | Uptime: {uptime_str}"

        else:
            metrics_text = "📊 Process: PID: -- | RAM: -- MB | Uptime: --"

            if self.bot_was_running:
                self.bot_was_running = False
                self.bot_start_time = None

                if pending_count > 0:
                    logger.warning(
                        f"🚨 CRASH DETECTED: UiPath stopped unexpectedly while {pending_count} file(s) are still pending!"
                    )
                    status_text = "🤖 UiPath: CRASHED / STOPPED UNEXPECTEDLY"
                    status_color = "red"
                    health_text = f"🔴 Health: CRASHED ({pending_count} Pending Files)"
                    health_color = "red"

                    if self.auto_recovery_var.get() and not self.is_recovering:
                        if self.recovery_attempts < self.max_recovery_retries:
                            if time.time() - self.last_recovery_time > self.recovery_cooldown:
                                self.trigger_auto_recovery(
                                    reason=f"Crash detected with {pending_count} unfinished files"
                                )
                        else:
                            logger.error(
                                f"🛑 Auto-Recovery: Maximum retry limit ({self.max_recovery_retries}) reached. Please inspect logs."
                            )
                else:
                    logger.info("UiPath process concluded normally. All files completed.")
                    status_text = "🤖 UiPath: FINISHED (ALL COMPLETED)"
                    status_color = "blue"
                    health_text = "🟢 Health: COMPLETED & IDLE"
                    health_color = "blue"
                    self.recovery_attempts = 0
            else:
                if hosts:
                    status_text = "🤖 UiPath: OPEN (IDLE)"
                    status_color = "#005b9f"
                    health_text = "🟡 Health: IDLE (Studio/Robot Open)"
                    health_color = "#005b9f"
                else:
                    status_text = "🤖 UiPath: OFFLINE"
                    status_color = "red"
                    health_text = "⚪ Health: OFFLINE"
                    health_color = "#555"

        self.lbl_uipath_status.config(text=status_text, foreground=status_color)
        self.lbl_health_badge.config(text=health_text, foreground=health_color)
        self.lbl_process_metrics.config(text=metrics_text)
        self.lbl_heartbeat.config(text=heartbeat_str, foreground=heartbeat_color)

        workload_str = f"📋 Workload: {completed_count} Completed"
        if pending_count > 0:
            workload_str += f" | {pending_count} Pending"
        if failed_count > 0:
            workload_str += f" | {failed_count} Failed"
        if current_file_active:
            workload_str += f" (Now: {current_file_active[:20]}...)"
        self.lbl_workload_status.config(text=workload_str)

        if self.recovery_attempts > 0:
            self.lbl_watchdog_status.config(
                text=f"🛡️ Watchdog: Recovered ({self.recovery_attempts}/{self.max_recovery_retries})",
                foreground="orange" if self.recovery_attempts < self.max_recovery_retries else "red"
            )
        else:
            self.lbl_watchdog_status.config(
                text="🛡️ Watchdog: Armed (0 Restarts)",
                foreground="#155724"
            )

        self.after(2000, self.check_uipath_health)

    def refresh_date_file_list(self):
        for item in self.tree_dates.get_children():
            self.tree_dates.delete(item)

        self.available_files_map.clear()

        active_folder = self.get_active_folder_path()
        if not active_folder or not active_folder.exists():
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.lbl_viewing_indicator.config(text=f"📄 [{self.active_folder_key}] Folder not found")
            return

        date_files = sorted(
            _daily_files(active_folder),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        today_str = datetime.now().strftime("%m%d%Y")
        today_item_id = None

        for filepath in date_files:
            filename = filepath.name
            raw_date = filename.replace("files_uploaded_", "").replace(".json", "")

            try:
                dt = datetime.strptime(raw_date, "%m%d%Y")
                display_date = dt.strftime("%b %d, %Y")
            except Exception:
                display_date = raw_date

            is_today = (raw_date == today_str)
            label_date = f"🟢 {display_date}" if is_today else f"📅 {display_date}"

            item_id = self.tree_dates.insert("", tk.END, values=(label_date, filename))
            self.available_files_map[item_id] = filepath

            if is_today:
                today_item_id = item_id

        target_select = today_item_id or (self.tree_dates.get_children()[0] if self.tree_dates.get_children() else None)
        if target_select:
            self.tree_dates.selection_set(target_select)
            self.tree_dates.focus(target_select)
            self.on_date_selected(None)
        else:
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.lbl_viewing_indicator.config(text=f"📄 [{self.active_folder_key}] (No files in folder)")

    def on_date_selected(self, event):
        selected = self.tree_dates.selection()
        if not selected:
            return

        item_id = selected[0]
        filepath = self.available_files_map.get(item_id)
        if not filepath or not filepath.exists():
            return

        self.currently_viewed_filepath = filepath
        self.lbl_viewing_indicator.config(text=f"📄 [{self.active_folder_key}] {filepath.name}")

        records = read_json_records(filepath)
        self.update_table(records)

    def apply_oauth_login(self):
        username = self.user_entry.get().strip()
        password = self.pwd_entry.get().strip()
        sec_token = self.token_entry.get().strip()

        if refresh_token_via_oauth(username, password, sec_token):
            logger.info("Salesforce authentication successful.")
        else:
            logger.error("Authentication failed. Check credentials and Security Token.")

    def _process_log_queue(self):
        while not log_queue.empty():
            msg = log_queue.get()
            self.log_text.insert(tk.END, msg + "\n")
            self.log_text.see(tk.END)
        self.after(100, self._process_log_queue)

    def start_monitoring(self):
        if not self.is_monitoring:
            self.is_monitoring = True
            self.lbl_status.config(text="⚡ Status: CONTINUOUS MONITORING ACTIVE", foreground="green")
            threading.Thread(target=self._worker_poll_loop, daemon=True).start()
            self.after(500, self.iconify)

    def update_table(self, file_results):
        self.current_results_cache = file_results

        selected = self.tree.selection()
        selected_file = None
        if selected:
            vals = self.tree.item(selected[0], "values")
            if vals:
                selected_file = vals[3]

        for item in self.tree.get_children():
            self.tree.delete(item)

        reselect_item = None
        for res in file_results:
            status = res.get("overall_status", "UNKNOWN")
            progress = f"{res.get('completed_jobs_count', 0)}/{res.get('total_jobs_detected', 0)}"
            duration = res.get("duration", "N/A")
            file_type = res.get("file_type", "N/A")
            dataset_id = res.get("dataset_id", "N/A")
            job_id = res.get("job_id", "N/A")
            fname = res.get("file_name", "")

            item_id = self.tree.insert(
                "",
                tk.END,
                values=(
                    file_type,
                    dataset_id,
                    job_id,
                    fname,
                    res.get("date_submitted", ""),
                    res.get("uploaded_by", "N/A"),
                    status,
                    progress,
                    res.get("start_time", "N/A"), 
                    res.get("end_time", "N/A"),   
                    duration,
                ),
                tags=(status,),
            )

            if selected_file and fname == selected_file:
                reselect_item = item_id

        if reselect_item:
            self.tree.selection_set(reselect_item)

    def _worker_poll_loop(self):
        logger.info("Starting continuous background monitoring loop...")
        self._last_completion_data = {}

        if self.token_entry.get().strip():
            refresh_token_via_oauth(
                self.user_entry.get().strip(),
                self.pwd_entry.get().strip(),
                self.token_entry.get().strip()
            )
        else:
            logger.info("Using active Session ID (sid) header for API requests.")

        while self.is_monitoring:
            any_files_found = False
            all_folders_completed = True

            for f_key, f_path in list(LOOKUP_FOLDERS.items()):
                if not f_path or not f_path.exists():
                    continue

                target_file_list, source_filepath = load_all_target_files(folder_path=f_path)
                if not target_file_list or not source_filepath:
                    continue

                any_files_found = True
                if f_key == self.active_folder_key:
                    self.active_monitored_filepath = source_filepath

                folder_results = []
                folder_all_completed = True

                for file_info in target_file_list:
                    file_status = fetch_file_job_status(file_info)
                    folder_results.append(file_status)

                    if not file_status.get("is_entirely_done", False):
                        folder_all_completed = False
                        all_folders_completed = False

                # Write / Update source input file (e.g., files_uploaded_MMDDYYYY.json) in this folder
                update_source_input_file(source_filepath, folder_results)

                # Write file_completion_status.json in this folder
                try:
                    folder_completion_file = f_path / "file_completion_status.json"
                    completion_data = (
                            {
                                "last_updated": datetime.now().isoformat(),
                                "folder_key": f_key,
                                "folder_path": str(f_path),
                                "total_files_monitored": len(folder_results),
                                "all_files_completed": folder_all_completed,
                                "files": folder_results,
                            }
                    )
                    # Only rewrite when something other than the timestamp changed (keeps OneDrive quiet)
                    compare_now = {k: v for k, v in completion_data.items() if k != "last_updated"}
                    if compare_now != self._last_completion_data.get(str(folder_completion_file)):
                        _atomic_write_json(folder_completion_file, completion_data)
                        self._last_completion_data[str(folder_completion_file)] = compare_now
                except Exception as e:
                    logger.error(f"Failed to write output JSON to {f_key} ({f_path}): {e}")

                # If this is the active folder currently selected in the UI, update the dashboard table
                if f_key == self.active_folder_key:
                    if self.currently_viewed_filepath == source_filepath or self.currently_viewed_filepath is None:
                        self.after(0, self.update_table, folder_results)

            if not any_files_found:
                time.sleep(POLL_INTERVAL_SECONDS)
                continue

            if all_folders_completed and any_files_found:
                self.after(
                    0,
                    lambda: self.lbl_status.config(
                        text="⚡ Status: ALL CURRENT FILES COMPLETED", foreground="blue"
                    ),
                )
            else:
                self.after(
                    0,
                    lambda: self.lbl_status.config(
                        text="⚡ Status: MONITORING IN PROGRESS...", foreground="green"
                    ),
                )

            time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    app = SalesforceMonitorApp()
    app.mainloop()