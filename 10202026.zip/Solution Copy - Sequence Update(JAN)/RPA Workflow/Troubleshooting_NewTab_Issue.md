# Troubleshooting Log — "New Tab Opens" Issue on Choose File Step
**Date:** September 8, 2026
**Activity affected:** Inside "Edge Recently Viewed Data Sets Salesforce" (NApplicationCard_5), the "Click 'File'" / "Inject Js Script" step

## Symptom
When the bot reaches the "Choose File" step in the Salesforce "New Data Set" form, instead of opening the native Windows file-picker dialog, a new blank Edge tab opens.

## Key Observation
- ✅ Works fine on the FIRST file/iteration.
- ❌ Starts failing (new tab opens) from the SECOND iteration onward.

## Fixes Already Applied (confirmed saved in Main.xaml)
1. ✅ Fixed `strEnvironment` → `in_Environment` bug in the `strURL` Assign (Assign_47).
2. ✅ Changed "Edge Recently Viewed Data Sets Salesforce" selector to wildcard: `<html title='*Salesforce' app='msedge.exe' />`
3. ✅ Disabled the original "Click 'File'" activity (CommentOut_4).
4. ✅ Added "Inject Js Script" (NInjectJsScript_1) activity in its place.

## Inject Js Script — Attempts So Far
- Attempt 1: Used "Indicate on screen" + `element.click()` — still opened new tab (theory: indicated wrong overlay element, not the real hidden `<input type="file">`).
- Attempt 2: Hardcoded `document.getElementById("j_id0:j_id5:j_id32:block1:j_id41:file").click()` — worked on file #1, broke on file #2+ (theory: Visualforce/JSF auto-generated IDs shift between page loads).
- Attempt 3: Switched to `document.querySelector('input[type=file]').click()` (more stable, doesn't depend on exact shifting ID) — wrapped in various function syntaxes, hit several VB-string-quoting and JS syntax errors along the way:
  - Error: "j_id5 is not declared" etc. → caused by unescaped double quotes breaking out of the VB String expression.
  - Error: "Unexpected token '{'" → caused by manually adding a `function(element,input){...}` wrapper that conflicted with the activity's own internal wrapping, PLUS stray duplicate quote characters.
  - Error: "n is not a function" → happened when the function wrapper was removed entirely; confirmed the activity DOES expect a proper function expression.
- Latest attempted final version (single line, meant to fix both syntax AND "not a function" issues):
  ```
  "function (element, input) { document.querySelector('input[type=file]').click(); }"
  ```
  ⚠️ Result: **Still opens a new tab.** Root cause not yet fully confirmed — possible theories not yet ruled out:
  - The activity's own internal wrapper might already implicitly include quotes/escaping we're not accounting for.
  - The new tab might not be caused by the file input click at all — could be a separate, unrelated Salesforce behavior (e.g., some other element on the page reacting to focus/hover after the "New" or "Save" steps).
  - Possible that "Inject Js Script" activity syntax requirements differ from standard JS (needs further doc lookup on exact expected format for this specific UiPath activity/version).

## Next Step Proposed (not yet implemented)
Add a **safety-net cleanup** step instead of continuing to chase the exact root cause:
1. After the file-choose step, add **Check App State** targeting an element unique to Edge's blank New Tab page.
2. If "Target appears" → send **Keyboard Shortcut Ctrl+W** to close that extra tab, then continue.
3. If "Target does not appear" → do nothing, continue normally.

## Other Still-Open Items (unrelated to this specific issue)
- Apex Job sequencing (Contacts → Absence → Disability) — PM's original request, not yet implemented. Reserved variables already exist: `apexJobId`, `jobStatus`, `allJobsCompleted`, `groupJobIds`, `failedJobMessage`.
- Email notification currently sends from Jay's personal Outlook account (via "Use Desktop Outlook App"), not a dedicated bot account — acceptable for now, upgradeable later.
- Stray unused variable in the workflow: `If_in_Environment_____ClaimConv_____...` (long auto-generated name) — safe to delete, not referenced anywhere.
