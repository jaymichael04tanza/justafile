# File Verification & JSON Transaction Log — Design & Build Guide
**For:** Jay Michael Tanza | **Project:** RPA Workflow
**Goal:** After processing file groups, verify each file within its category (following a strict hierarchy), log each verification with duration, and produce a final JSON transaction log file named with the current date/time.

---

## 1. The Hierarchy (Priority Order)
| Order | Category Keyword |
|---|---|
| 0 | contacts |
| 1 | workschedule |
| 2 | absence_claims |
| 3 | disability_claims |
| 4 | relationship |
| 5 | medical_diagnosis |
| 6 | physician |
| 7 | appeals |
| 8 | payment_specification |
| 9 | adjustment |

Example real files seen: `LeaveLink_Absence_Claims_LoadReadyFile_June04_part00.csv` ... `part04.csv`, `PACS_Disability_Claims_LoadReadyFile_Jun05_PilotCustomers_part01.csv` ... etc.

## 2. What "Verify" Means Here
For each file belonging to the current category (in the hierarchy order above):
1. Record a start time.
2. Perform the verification check (placeholder for now — could later be expanded to check the Salesforce Data Set/Job status; for now, it will just confirm the file was processed in the earlier upload loop, e.g., by checking it exists in `fileGroups`).
3. Record end time → compute duration.
4. Log a message: `"<FileName> - Verified | Duration: <duration>"`
5. Record this result into a growing in-memory data structure (a Dictionary/JObject) that will become part of the final JSON.

After ALL files in a category are verified:
6. Log: `"<Category> - Complete | Duration of verifying: <date/time>"`
7. Record a summary entry into the JSON structure too.

If a category has NO matching files at all → skip it, log something like `"<Category> - No files found, skipped."`, and move to the next category in the hierarchy.

## 3. Final Output
Once all 10 categories have been checked (verified or skipped), serialize the entire in-memory log structure into JSON text, and write it to a file named:
```
Transaction<yyyyMMdd_HHmmss>.json
```
(e.g., `Transaction20260908_235959.json`)

## 4. New Variables Needed
| Variable | Type | Purpose |
|---|---|---|
| `verificationHierarchy` | List(Of String) | The 10 category keywords, in priority order |
| `verificationLog` | JObject (or Dictionary(Of String, Object)) | The growing master record of all verification results |
| `currentCategory` | String | Loop variable — current category being checked |
| `matchingGroupKey` | String | The actual `fileGroups` key that matches the current category (if any) |
| `categoryStartTime` / `categoryEndTime` | DateTime | Track how long verifying a whole category took |
| `fileStartTime` / `fileEndTime` | DateTime | Track how long verifying one file took |
| `verifyFileItem` | Object | Loop variable — current file being verified within a category |
| `jsonOutputPath` | String | Full path for the final Transaction*.json file |

## 5. High-Level Flow (Pseudocode)
```
Assign verificationHierarchy = New List(Of String) From {"contacts","workschedule","absence_claims",
    "disability_claims","relationship","medical_diagnosis","physician","appeals",
    "payment_specification","adjustment"}
Assign verificationLog = New JObject()

For Each currentCategory In verificationHierarchy
    Assign matchingGroupKey = fileGroups.Keys.FirstOrDefault(Function(k) k.ToLower.Contains(currentCategory))

    If String.IsNullOrEmpty(matchingGroupKey) Then
        Log Message: currentCategory & " - No files found, skipped."
        ' add to verificationLog too, e.g. verificationLog(currentCategory) = "Skipped - no files"
    Else
        Assign categoryStartTime = Now

        For Each verifyFileItem In fileGroups(matchingGroupKey)
            Assign fileStartTime = Now
            ' [verification check placeholder]
            Assign fileEndTime = Now
            Log Message: verifyFileItem.Name & " - Verified | Duration: " & (fileEndTime - fileStartTime).ToString
            ' Add result into verificationLog, e.g.:
            ' verificationLog(verifyFileItem.Name.Replace(".csv","")) = "Verified"
        End For

        Assign categoryEndTime = Now
        Log Message: currentCategory & " - Complete | Duration of verifying: " & (categoryEndTime - categoryStartTime).ToString & " | " & Now.ToString
        ' verificationLog(currentCategory & "_Summary") = "Complete | Duration: ... | " & Now.ToString
    End If
End For

Assign jsonOutputPath = <folder> & "\Transaction" & Now.ToString("yyyyMMdd_HHmmss") & ".json"
Write Text File: verificationLog.ToString() → jsonOutputPath
```

## 6. Example Resulting JSON (conceptual)
```json
{
  "contacts": "Skipped - no files",
  "Absense_Claims_00": "Verified",
  "Absense_Claims_01": "Verified",
  "Absense_Claims_02": "Verified",
  "Absense_Claims_03": "Verified",
  "Absense_Claims_04": "Verified",
  "absence_claims_Summary": "Complete | Duration: 00:00:12 | 2026-09-09 00:15:32",
  "disability_claims_Summary": "Complete | Duration: 00:00:20 | 2026-09-09 00:16:10",
  "relationship": "Skipped - no files",
  ...
}
```

---
*This is a planning document — no changes have been made to Main.xaml yet. Follow-up chat messages will contain the step-by-step Studio build instructions matching this design.*
