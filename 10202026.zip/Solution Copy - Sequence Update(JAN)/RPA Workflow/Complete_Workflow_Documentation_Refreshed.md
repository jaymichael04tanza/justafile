# Complete Workflow Documentation (Refreshed) — Main.xaml
**For:** Jay Michael Tanza
**Project:** RPA Workflow
**Last Refreshed:** September 8, 2026 (based on the latest saved version of Main.xaml)
**Purpose:** A beginner-friendly, very detailed, activity-by-activity explanation of the entire workflow, reflecting the most current state of the file.

---

## 📖 Table of Contents
1. [Big Picture](#1-big-picture)
2. [Chapter 1 — Starting the Bot](#chapter-1)
3. [Chapter 2 — Getting & Sorting the Files](#chapter-2)
4. [Chapter 3 — Grouping Files by Category](#chapter-3)
5. [Chapter 4 — The Main Upload Loop (Salesforce)](#chapter-4)
6. [Chapter 5 — Auto-Login & Email Notification](#chapter-5)
7. [Full Variable Glossary (current, from live file)](#6-variable-glossary)
8. [Known Issues & Open Items](#7-known-issues)
9. [Change Log](#8-change-log)

---

<a name="1-big-picture"></a>
## 1. Big Picture

This workflow automates uploading CSV files from a OneDrive folder into Salesforce as "Data Set" records — grouped and processed in a specific order (Contacts → Absence Claims → Disability Claims → others), with a self-healing login system that detects if the Salesforce session is logged out, logs back in automatically using saved JSON credentials, and sends an email notification once done.

---

<a name="chapter-1"></a>
## Chapter 1 — Starting the Bot

### 1.1 Manual Trigger
The starting point — waits for a person to click "Run." Expects the input argument `in_Environment` (e.g., `"ClaimConv"` or `"ClaimConv1"`) to tell the bot which Salesforce sandbox to use later.

### 1.2 Get File or Folder List
Connects to the OneDrive/SharePoint folder `One Drive/General/CSV to be Loaded` and retrieves up to 200 files (Files only). Result stored in `allFiles` (type: `O365DriveRemoteItem[]`).
⚠️ No file-type filter applied; 200-file cap could silently skip files if volume grows.

---

<a name="chapter-2"></a>
## Chapter 2 — Getting & Sorting the Files

### 2.1 Assign — `orderedFiles = allFiles.ToList()`
Converts the fixed-size `allFiles` array into a flexible `List` so it can be freely re-sorted.

### 2.2 Assign — Reorder `orderedFiles`
Custom priority sort: files with **"contacts"** in the name first, then **"absence_claims"**, then **"disability_claims"**, then everything else — alphabetically within each group. This is what guarantees Contacts get processed before Absence/Disability later.

### 2.3 Assign - Upload Type Dictionary — builds `uploadTypeMap`
Builds a lookup table (`Dictionary(String, String)`) mapping filename keywords to Salesforce "Upload Type" values (e.g., "Contacts" → "Cv Demographics Default").

---

<a name="chapter-3"></a>
## Chapter 3 — Grouping Files by Category

A loop ("For Each item") goes through `orderedFiles` one file at a time:

1. **Log Message** — logs the current file (or "ITEM IS NULL" as a safety check).
2. **Assign `matchedKey`** — checks if the filename matches any keyword in `uploadTypeMap`.
3. **Assign `groupName`** — the matched category, or the filename itself if no match.
4. **If** `fileGroups` doesn't contain `groupName` yet → **Then:** create a new empty list for it. **Else:** do nothing.
5. **Invoke Method "Add"** — adds the file into its group's list inside `fileGroups`.
6. **Log Message** — logs total group count so far.

End result: `fileGroups` holds buckets like Contacts, Absence Claims, Disability Claims (and possibly others), each with their respective files.

---

<a name="chapter-4"></a>
## Chapter 4 — The Main Upload Loop (Salesforce)

Loop "For Each currentGroup" iterates `fileGroups.Keys` (in Contacts → Absence → Disability order), and inside it, "For Each fileItem" iterates the files in that group:

### 4.1 Safety Check
**If** `fileItem` is Nothing → logs "fileItem is Null" and skips.

### 4.2 Else (valid file) — full sequence:
- **Download File** → to `C:\Users\205tjx\Downloads` (⚠️ hardcoded path).
- **Assign `datasetName1`** → the file's name (used as the new Salesforce record name).
- **Assign `uploadTypeValue`** → matched against `uploadTypeMap`; defaults to `"DefaultUploadType"`.
- **Assign `strURL`** → picks the Salesforce sandbox URL based on `in_Environment`:
  ```vb
  strURL = If(in_Environment = "ClaimConv",
               "https://rsl-matrix--claimconv.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent",
           If(Equals(strEnvironment, "ClaimConv1"),
               "https://rsl-matrix--claimconv1.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent",
               String.Empty))
  ```
  ⚠️ **STILL NOT FIXED:** 2nd condition checks the unused `strEnvironment` variable instead of `in_Environment` — the "ClaimConv1" path is still unreachable as of this refresh.

- **"Edge Recently Viewed Data Sets Salesforce"** (the big App Card) — now starts with the full login-check sequence (see Chapter 5) BEFORE any of these:
  - Click 'New' → Type Into 'Data Set Name' → Type Into 'Upload Type' → Click 'File' → (nested) File Explorer: type path + Enter → Click 'Save' → Delay 3s → Click 'Start Upload' → Delay 2s → Keyboard Shortcut (Enter, dismiss popup) → Click 'Data Sets' (back to list).

---

<a name="chapter-5"></a>
## Chapter 5 — Auto-Login & Email Notification

Added as the very FIRST activities inside "Edge Recently Viewed Data Sets Salesforce," before "Click 'New'":

### 5.1 Check App State 'Username'
Checks if the Username input box is currently visible (i.e., session logged out and Salesforce redirected to its login page).
- **Wait for:** "Element to appear"
- **Target appears** → logged out → run login steps 5.2–5.12 below
- **Target does not appear** → already logged in → skip straight to "Click 'New'"

### 5.2 Read Text File
Reads `credentials.json` → `jsonContent` (String).
```json
{
  "email": "jay.michael.m.tanza@accenture.com.claimconv",
  "password": "Cebu@4826Jay",
  "notificationEmail": "Jay.Tanza@reliancematrix.com"
}
```

### 5.3 Deserialize JSON
Parses `jsonContent` → `credentialsObject` (Type: `JObject`).

### 5.4–5.6 Assign — Extract Credentials
```vb
credEmail = credentialsObject("email").ToString
credPassword = credentialsObject("password").ToString
credNotifyEmail = credentialsObject("notificationEmail").ToString
```

### 5.7 Type Into 'Username' (Screen 1)
Types `credEmail` into the Username field.

### 5.8 Click 'Log In to Sandbox' (1st click)
Submits username → Salesforce shows Screen 2 (Password field appears).

### 5.9 Type Into 'Password' (Screen 2)
Types `credPassword` into the newly-visible Password field.

### 5.10 Click 'Log In to Sandbox' (2nd/final click)
Submits the full login.

### 5.11 Use Desktop Outlook App
Scope activity — uses the already-signed-in Outlook desktop session, no password needed.
- **Account:** `Jay.Tanza@reliancematrix.com`
- **Reference as:** `Outlook`

### 5.12 Send Email (inside the scope)
- **Account:** `Outlook`
- **To:** `credNotifyEmail`
- **Subject:** `"RPA Bot - Salesforce Successfull!"`
- **Body:** `"The Bot successfully logged into Salesforce and started processing the file upload."`
- **Save as draft:** Unchecked (False) — required so it actually sends, not just drafts.

**Why this specific email approach was chosen:** After trying the Office 365 connector (needed Orchestrator Mail scope), the connector-based "Send SMTP Email" (needed a ConnectionId), and the classic "Send SMTP Email" (needed real email/password credentials Jay didn't have for a bot account), "Use Desktop Outlook App" was chosen because it requires **zero passwords** — it simply reuses whatever Outlook is already open and signed in on the machine. Trade-off: the email currently sends from Jay's own address rather than a dedicated bot identity (e.g., "RPAbottest@reliancematrix.com") — acceptable for now, upgradeable later once IT grants "Send As" permission on a shared mailbox or provides real bot credentials.

### "Target does not appear" branch
Left empty — already logged in, nothing to do.

---

<a name="6-variable-glossary"></a>
## Full Variable Glossary (from the live file, as of this refresh)

| Variable | Type | Purpose |
|---|---|---|
| `variable1` | String | Unused/leftover |
| `currentGroup` | Object | Loop variable (legacy/unused in current loops — actual group loop uses `currentGroup` as String in the "For Each currentGroup" loop body scope) |
| `tempList` | List | Temporary list helper |
| `strURL` | String | Salesforce URL to open, based on `in_Environment` |
| `strEnvironment` | String | ⚠️ Declared but never assigned — root of the known `strURL` bug |
| `orderedFiles` | List | Files sorted into Contacts → Absence → Disability → others |
| `allFiles` | O365DriveRemoteItem[] | Raw file list from OneDrive |
| `CSVFiles` | List | Declared, appears unused in the main flow shown |
| `datasetName1` | String | Name for the new Salesforce Data Set record |
| `dataset` | Int64 | Declared, not actively used in the traced flow |
| `lreadyfiles` | O365DriveRemoteItem | Declared, not actively used in the traced flow |
| `uploadTypeMap` | Dictionary | Filename keyword → Salesforce Upload Type lookup |
| `matchedItem` | KeyValuePair | Holds the matched entry from `uploadTypeMap` during file processing |
| `uploadTypeValue` | String | The Upload Type to select in Salesforce for the current file |
| `failedJobMessage` | String | ⚠️ Reserved, not yet wired — for future Apex Job failure logging |
| `jobStatus` | String | ⚠️ Reserved, not yet wired — for future Apex Job status polling |
| `allJobsCompleted` | Boolean | ⚠️ Reserved, not yet wired — flag for future Apex Job polling loop |
| `apexJobId` | String | ⚠️ Reserved, not yet wired — for future Apex Job id tracking |
| `groupJobIds` | List | ⚠️ Reserved, not yet wired — for tracking multiple job ids per group |
| `currentGroupName` | String | Declared, likely a duplicate/helper for `currentGroup` |
| `groupName` | String | The matched category name during file grouping (Chapter 3) |
| `matchedKey` | String | The matched `uploadTypeMap` keyword during grouping |
| `fileGroups_groupName_` | List | Auto-generated helper variable (from indexing `fileGroups(groupName)`) |
| `fileGroups` | Dictionary | Files organized into category buckets |
| `fileItem` | Dictionary | The current file entry being processed (inner loop) |
| `totalNumberOfFilesOrFoldersProcessed` | Int32 | Counter, likely tied to the "Get File or Folder List" activity metadata |
| `CurrentItemIndex` | Int32 | Loop index helper |
| `in_Environment` | String (input argument) | Determines which Salesforce sandbox environment to use |
| *(scoped, not shown at root level)* `jsonContent`, `credentialsObject`, `credEmail`, `credPassword`, `credNotifyEmail` | String / JObject | Login credential variables — these live inside the "Check App State → Target appears" branch, so they don't appear in the root-level variable list, but are fully functional there (see Chapter 5) |

---

<a name="7-known-issues"></a>
## Known Issues & Open Items (still pending as of this refresh)

1. **`strEnvironment` vs `in_Environment` bug** — still present in the `strURL` Assign; "ClaimConv1" path still unreachable.
2. **Hardcoded download path** (`C:\Users\205tjx\Downloads`).
3. **Fixed Delays (3s, 2s)** in the Salesforce UI sequence.
4. **Apex Job sequencing (PM's original request)** — Contacts → Absence → Disability completion-check logic is still NOT implemented. The reserved variables (`apexJobId`, `jobStatus`, `allJobsCompleted`, `groupJobIds`, `failedJobMessage`) remain unused.
5. **Email sender identity** — still sends as Jay's personal account, not a dedicated bot account.
6. **No explicit error handling** around UI interactions.
7. **No file-type filter** on file retrieval.
8. **200-file cap** on file retrieval.

---

<a name="8-change-log"></a>
## Change Log (what's new since the previous documentation)

- ✅ Confirmed the full Auto-Login sequence (Chapter 5) is saved and intact in the current file, nested inside `NApplicationCard_5`'s "Check App State → Target appears" branch.
- ✅ Confirmed credential variables (`jsonContent`, `credentialsObject`, `credEmail`, `credPassword`, `credNotifyEmail`) are correctly scoped inside that branch (this is why they don't show in the root-level Variables list — expected behavior, not a regression).
- ✅ Confirmed the "Use Desktop Outlook App" + "Send Email" notification setup is in place.
- ⏳ No changes yet to the `strURL`/`strEnvironment` bug, hardcoded download path, or Apex Job sequencing — all still open.

---

*Document generated as a complete, refreshed reference guide based on the latest saved workflow file. No changes were made to Main.xaml while creating this document.*
