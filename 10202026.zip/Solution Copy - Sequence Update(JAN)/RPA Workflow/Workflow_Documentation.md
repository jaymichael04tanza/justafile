# RPA Workflow Documentation — Main.xaml
**Project:** RPA Workflow
**Prepared for:** Jay Michael Tanza
**Purpose:** Automates the bulk upload of CSV files from OneDrive into Salesforce Data Sets, grouped and ordered by data category (Contacts → Absence Claims → Disability Claims → others).

---

## 1. Overall Purpose

This workflow:
1. Pulls CSV files from a OneDrive/SharePoint folder (`CSV to be Loaded`).
2. Sorts and groups them by data category based on filename keywords (Contacts, Absence_Claims, Disability_Claims, etc.).
3. Downloads each file locally.
4. Uploads each file into Salesforce as a new "Data Set" record, using UI Automation on Microsoft Edge.
5. Triggers the Salesforce "Start Upload" action to kick off the backend Apex data-load job for each file.

---

## 2. Step-by-Step Activity Breakdown

### CHAPTER 1: Kick-off

**1. Manual Trigger**
- Starting point of the automation; requires manual run.
- Expects the input argument `in_Environment` to be provided (e.g., `"ClaimConv"` or `"ClaimConv1"`) — this determines which Salesforce sandbox URL is used later.

**2. Get File or Folder List**
- Connects to OneDrive/SharePoint folder: `One Drive/General/CSV to be Loaded`
- Retrieves up to 200 files (Files only, not folders)
- Sort Options: Ascending (gets overridden by custom sort logic later)
- Result stored in variable: `allFiles` (type: `O365DriveRemoteItem[]`)

⚠️ **Note:** No file-type filter is applied — non-CSV files dropped in that folder would also get pulled into `allFiles`.
⚠️ **Note:** The 200-file cap could silently skip files if the folder ever exceeds that volume.

---

### CHAPTER 2: Sorting & Categorizing

**3. Assign** — `orderedFiles = allFiles.ToList()`
- Converts the `allFiles` array into a List for easier sorting/manipulation.

**4. Assign** — Reorder `orderedFiles`
- Custom priority sort: files containing "contacts" first, then "absence_claims", then "disability_claims", then everything else — alphabetically within each group.
- This establishes the **Contacts → Absence → Disability** processing order used later.

**5. Assign - Upload Type Dictionary** — builds `uploadTypeMap`
- A `Dictionary(String, String)` mapping filename keywords to Salesforce "Upload Type" values, e.g.:
  - "Contacts" → "Cv Demographics Default"
  - "Absence_Claims" → "ImportedAbsenceClaimProcessorV2"
  - (and similar mappings for Disability_Claims, etc.)

---

### CHAPTER 3: "For Each item" Loop — Grouping Files

Iterates through `orderedFiles`, one file at a time, building the `fileGroups` dictionary (category → list of files):

1. **Log Message** — logs the current file (or "ITEM IS NULL" as a safety check).
2. **Assign** — determines `matchedKey` (which `uploadTypeMap` keyword matches this filename, if any).
3. **Assign** — determines `groupName` (matched category, or filename without extension if no match).
4. **If** `fileGroups` doesn't contain `groupName` yet:
   - **Then:** create a new empty list for this group.
   - **Else:** do nothing (group already exists).
5. **Invoke Method "Add"** — adds the file into its group's list inside `fileGroups`.
6. **Log Message** — logs total group count so far (e.g., "Groups=3").

Result: `fileGroups` ends up with buckets like Contacts, Absence Claims, Disability Claims (and possibly others), each containing their respective files.

---

### CHAPTER 4: "For Each currentGroup" Loop — Salesforce Upload (Main Process)

Iterates through `fileGroups.Keys` (in Contacts → Absence → Disability order, per the earlier sort):

1. **Log Message** — logs `currentGroup` name.
2. **Log Message** — logs number of files in this group.
3. **"For Each fileItem" loop** — iterates through files within the group:

   **a. If `fileItem` is Nothing:**
   - Logs "fileItem is Null" and skips (safety check).

   **b. Else (valid file):**
   - **Download File** — downloads from OneDrive to local path `C:\Users\205tjx\Downloads`.
     - ⚠️ Hardcoded path — not portable across machines/users.
   - **Assign `datasetName1`** — sets to the downloaded file's name (used as the Salesforce Data Set record name).
   - **Assign `uploadTypeValue`** — matches filename against `uploadTypeMap` again; defaults to `"DefaultUploadType"` if no match.
   - **Assign `strURL`** — picks Salesforce sandbox URL based on `in_Environment`:
     ```vb
     strURL = If(in_Environment = "ClaimConv",
                  "https://rsl-matrix--claimconv.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent",
              If(Equals(strEnvironment, "ClaimConv1"),
                  "https://rsl-matrix--claimconv1.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent",
                  String.Empty))
     ```
     ⚠️ **BUG FOUND:** The second condition checks `strEnvironment` (a variable that is declared but never assigned anywhere in the workflow) instead of `in_Environment`. This means:
     - If `in_Environment = "ClaimConv1"` is passed, this condition will NEVER match.
     - `strURL` falls through to `String.Empty`.
     - The Salesforce automation card then opens Edge with a blank URL, resulting in just a blank "New Tab" page opening instead of navigating to Salesforce — exactly the symptom observed during testing.
     - **Recommended fix:** change `strEnvironment` to `in_Environment` in that condition.
   - Also make sure `in_Environment` is actually supplied as an input argument when running manually (via Debug/Run input arguments dialog) — if left blank, both conditions fail and `strURL` is empty regardless of the bug above.

   **c. "Edge Recently Viewed Data Sets Salesforce" (NApplicationCard)** — opens/reuses Edge at `strURL` and performs:
   - **Click 'New'** — starts a new Data Set record.
   - **Type Into 'Data Set Name'** — types `datasetName1`.
   - **Type Into 'Upload Type'** — selects `uploadTypeValue` from dropdown.
   - **Click 'File'** — opens the Windows file picker dialog.
   - **(Nested App Card) File Explorer dialog:**
     - Types the full file path (`datasetName1 + ".csv"`) into the "File name" field.
     - Presses Enter to select the file.
   - **Click 'Save'** — saves the new Data Set record.
   - **Delay (3 seconds)** — fixed wait.
     - ⚠️ Consider replacing with a "Wait for element" / "Element Exists" check for reliability and speed.
   - **Click 'Start Upload'** — triggers the Apex batch job / data-load process in Salesforce.
   - **Delay (2 seconds)** — fixed wait.
   - **Keyboard Shortcut (Enter)** — dismisses a confirmation popup dialog that appears after starting the upload.
   - **Click 'Data Sets'** — navigates back to the Data Sets list page, ready for the next file.

4. Loop repeats for the next `fileItem`, then moves to the next `currentGroup`, until all groups/files are processed.

---

## 3. Visual Flow Summary

```
Manual Trigger
   ↓
Get Files from OneDrive → allFiles
   ↓
Sort/Order → orderedFiles (Contacts → Absence → Disability → others)
   ↓
Build uploadTypeMap (keyword → Salesforce Upload Type)
   ↓
Group files → fileGroups (by category)
   ↓
FOR EACH GROUP (Contacts, then Absence, then Disability):
   FOR EACH FILE in that group:
      Download → Set Data Set Name/Type → Open Salesforce →
      Click New → Fill fields → Attach file → Save → Start Upload →
      Confirm popup → Back to Data Sets list
```

---

## 4. Known Issues / Improvement Opportunities

| # | Issue | Impact | Suggested Fix |
|---|---|---|---|
| 1 | `strEnvironment` vs `in_Environment` bug in `strURL` Assign | "ClaimConv1" environment path is unreachable; can cause blank browser tab | Change condition to check `in_Environment` instead of `strEnvironment` |
| 2 | Hardcoded download path (`C:\Users\205tjx\Downloads`) | Not portable to other machines/users | Use a configurable path (Asset, config file, or temp folder) |
| 3 | Fixed Delays (3s, 2s) | Slower than necessary, or too short if Salesforce lags | Replace with "Wait for Ready"/"Element Exists" checks |
| 4 | No group-completion check between Contacts → Absence → Disability | Absence/Disability could start before Contacts' Apex Job actually finishes processing in Salesforce (per PM's requirement) | Add Apex Job status polling (Completed/Failed) between groups using the already-declared but unused variables: `apexJobId`, `jobStatus`, `allJobsCompleted`, `groupJobIds`, `failedJobMessage` |
| 5 | No explicit error handling around UI interactions | A missing/changed UI element could crash the whole run without clear context | Wrap key UI interactions in Try Catch blocks |
| 6 | Long/complex Salesforce selectors (`sfl-path`, `tableRow` attributes) | Fragile if Salesforce UI changes | Review selectors for stability; use more reliable attributes where possible |
| 7 | No file-type filter on "Get File or Folder List" | Non-CSV files in the source folder would also get pulled in | Add a filter for `*.csv` files only |
| 8 | 200-file cap on file retrieval | Files could be silently skipped if volume grows past 200 | Increase `MaxResults` or add pagination if needed |

---

## 5. Variables Already Declared But Not Yet Used (relevant to PM's sequencing requirement)

These exist in the workflow's variable list but have no logic wired to them yet — they appear to be placeholders for the Apex Job completion-check feature the PM requested:

- `apexJobId` (String) — intended to store the job id after triggering an upload.
- `jobStatus` (String) — intended to store the current status while polling.
- `allJobsCompleted` (Boolean) — intended as a flag to indicate the polling loop is done.
- `groupJobIds` (List of String) — intended to track multiple job ids per group.
- `failedJobMessage` (String) — intended for logging errors if a job fails.

**Conceptual plan (not yet implemented) for the PM's requirement:**
1. After all files in the Contacts group finish uploading, check the Apex Job status in Salesforce (e.g., via Setup → Apex Jobs monitor, or a status field on the Data Set record).
2. Poll (While loop + Delay) until status = "Completed" before starting the Absence Claims group.
3. Repeat the same check after Absence, before starting Disability.
4. If a job shows "Failed", log the error to `failedJobMessage` and stop/handle before proceeding.

---

*Document generated as a reference summary — no changes were made to the actual workflow file.*
