# Complete Workflow Documentation — Main.xaml (RPA Workflow)
**For:** Jay Michael Tanza
**Project:** RPA Workflow
**Purpose:** A beginner-friendly, very detailed explanation of every single activity in this automation, in the exact order they run.

---

## 📖 Table of Contents
1. [What This Whole Workflow Does (Big Picture)](#1-big-picture)
2. [Chapter 1 — Starting the Bot](#chapter-1)
3. [Chapter 2 — Getting & Sorting the Files](#chapter-2)
4. [Chapter 3 — Grouping Files by Category](#chapter-3)
5. [Chapter 4 — The Main Upload Loop (Salesforce)](#chapter-4)
6. [Chapter 5 — Auto-Login & Email Notification (New Feature)](#chapter-5)
7. [Full Variable Glossary](#6-variable-glossary)
8. [Known Issues & Open Items](#7-known-issues)

---

<a name="1-big-picture"></a>
## 1. What This Whole Workflow Does (Big Picture)

Imagine you have a stack of CSV files sitting in a OneDrive folder, and every single day, someone has to:
1. Open each file,
2. Figure out what "type" of data it is (Contacts? Claims?),
3. Go to Salesforce,
4. Manually create a new record, upload the file, and click a few buttons to start processing it.

This workflow **automates that entire manual process.** It also now includes a **smart login system** — if the bot finds itself logged out of Salesforce, it automatically logs back in using saved credentials, and even sends you an **email notification** once it's done logging in.

Think of the whole workflow as one long recipe with 5 main "chapters," which we'll walk through one at a time.

---

<a name="chapter-1"></a>
## Chapter 1 — Starting the Bot

### 1.1 Manual Trigger
**What it is:** The starting point. Nothing happens until a person clicks "Run" in Studio (or an Orchestrator job triggers it).
**Beginner explanation:** Think of this as the "Start" button on a machine — the bot just waits here until someone tells it to go.
**Important detail:** This workflow expects an **input argument** called `in_Environment` to be provided when you run it (values like `"ClaimConv"` or `"ClaimConv1"`). This tells the bot which Salesforce sandbox environment to connect to later.

### 1.2 Get File or Folder List
**What it is:** Connects to a OneDrive/SharePoint folder and lists all the files inside it.
**Beginner explanation:** Imagine walking into a room and taking a photo of every document sitting on a table — that's what this step does, except with files in a cloud folder.
**Configuration:**
- **Folder:** `One Drive/General/CSV to be Loaded`
- **Max Results:** 200 (it will only grab up to 200 files at once)
- **What to Return:** Files only (ignores subfolders)
- **Result stored in:** `allFiles` variable
**⚠️ Things to watch out for:**
- No filter for file type — if someone drops a non-CSV file in that folder, it gets picked up too.
- The 200-file cap could silently skip files if the folder ever holds more than that.

---

<a name="chapter-2"></a>
## Chapter 2 — Getting & Sorting the Files

### 2.1 Assign — `orderedFiles = allFiles.ToList()`
**Beginner explanation:** `allFiles` comes back as a fixed-size "array" (like a sealed box you can't add/remove items from). This step just pours those files into a flexible "List" (like an open basket you CAN add/remove items from), so the next steps can rearrange them freely.

### 2.2 Assign — Reorder `orderedFiles`
**Beginner explanation:** This step is like sorting a stack of mixed papers into 3 piles, always in the same order:
1. Any file with **"contacts"** in its name → goes to the FRONT of the pile.
2. Any file with **"absence_claims"** → goes next.
3. Any file with **"disability_claims"** → goes next.
4. Everything else → goes last.
Within each pile, files are also sorted alphabetically.
**Why this matters:** This is what guarantees Contacts files get processed before Absence/Disability files later on — which ties directly into your PM's request about sequencing!

### 2.3 Assign - Upload Type Dictionary — builds `uploadTypeMap`
**Beginner explanation:** This creates a "cheat sheet" (a Dictionary — basically a lookup table with Key → Value pairs) that says: *"If a filename contains THIS keyword, then its Salesforce Upload Type should be THAT value."*

Example entries:
| Filename keyword (Key) | Salesforce Upload Type (Value) |
|---|---|
| "Contacts" | "Cv Demographics Default" |
| "Absence_Claims" | "ImportedAbsenceClaimProcessorV2" |
| "Disability_Claims" | (similar mapping) |

---

<a name="chapter-3"></a>
## Chapter 3 — Grouping Files by Category

This whole chapter is one big loop called **"For Each item"** that goes through `orderedFiles` one file at a time.

### 3.1 Log Message
**Beginner explanation:** Just prints out which file is currently being looked at (or "ITEM IS NULL" if something went wrong) — this is purely for debugging/visibility, doesn't change any data.

### 3.2 Assign — figure out `matchedKey`
**Beginner explanation:** Checks the current file's name against every keyword in `uploadTypeMap` to see if any of them match. If "Absence_Claims" is found in the filename, `matchedKey` becomes "Absence_Claims".

### 3.3 Assign — figure out `groupName`
**Beginner explanation:** If a match was found in step 3.2, `groupName` becomes that matched keyword. If NOT, `groupName` just becomes the filename itself (so unmatched files still get their own "group," even if it's a group of one).

### 3.4 If — "Does this group already exist?"
**Beginner explanation:** This checks a box (`fileGroups`) that holds all the categories seen so far.
- **If NOT there yet (Then branch):** Create a brand new empty list for this category.
- **If already there (Else branch):** Do nothing, it already exists.

### 3.5 Invoke Method "Add"
**Beginner explanation:** Actually places the current file into its category's list inside `fileGroups`. Think of it as literally dropping the paper into the correct labeled folder.

### 3.6 Log Message
**Beginner explanation:** Prints how many total categories/groups exist so far (e.g., "Groups=3" — meaning Contacts, Absence, and Disability groups have been created).

**End result of Chapter 3:** `fileGroups` is now a dictionary that looks conceptually like:
```
fileGroups = {
  "Cv Demographics Default": [contacts_file1.csv, contacts_file2.csv, ...],
  "ImportedAbsenceClaimProcessorV2": [absence_file1.csv, ...],
  "DisabilityClaimUploadType": [disability_file1.csv, ...]
}
```

---

<a name="chapter-4"></a>
## Chapter 4 — The Main Upload Loop (Salesforce)

This is the **big one** — a loop called **"For Each currentGroup"** that goes through each category in `fileGroups`, and inside it, another loop **"For Each fileItem"** that goes through each file within that category.

### 4.1 Log Message (x2)
Prints the current group's name, and how many files are in it. Just for visibility/debugging.

### 4.2 "For Each fileItem" loop
For every single file inside the current group:

#### 4.2.a If `fileItem` is Nothing
**Beginner explanation:** A safety check — "is this file slot actually empty/broken?" If yes, just log "fileItem is Null" and skip it, don't try to process a file that doesn't exist.

#### 4.2.b Else (normal case — a real file exists)

**Download File**
- Downloads the file from OneDrive to your local computer, into `C:\Users\205tjx\Downloads`.
- ⚠️ This exact folder path is "hardcoded" (typed in directly) — it only works on this specific computer/user account.

**Assign `datasetName1`**
- Sets this variable to the file's name — this becomes the name of the new Salesforce record we're about to create.

**Assign `uploadTypeValue`**
- Looks up the file's name against `uploadTypeMap` again to determine the correct "Upload Type" to select in Salesforce's dropdown. Defaults to `"DefaultUploadType"` if nothing matches.

**Assign `strURL`**
- Decides WHICH Salesforce sandbox web address to open, based on the `in_Environment` value:
```vb
strURL = If(in_Environment = "ClaimConv",
             "https://rsl-matrix--claimconv.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent",
         If(Equals(strEnvironment, "ClaimConv1"),
             "https://rsl-matrix--claimconv1.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent",
             String.Empty))
```
- ⚠️ **KNOWN BUG:** The 2nd condition checks a totally different, never-used variable called `strEnvironment` instead of `in_Environment`. This means if you pass `"ClaimConv1"`, it will NEVER match, and `strURL` becomes empty — causing the browser to open a blank page instead of Salesforce. **Not yet fixed** — flagged for your team.

**"Edge Recently Viewed Data Sets Salesforce" (the big App Card)**
This single activity opens Microsoft Edge and does a whole chain of things inside it — see Chapter 5 for the NEW login-check logic that now runs FIRST, before any of these:
- **Click 'New'** — clicks the button to start creating a new Data Set record.
- **Type Into 'Data Set Name'** — types `datasetName1` into the name field.
- **Type Into 'Upload Type'** — selects `uploadTypeValue` from the dropdown.
- **Click 'File'** — opens the Windows file picker.
- **(Nested card) File Explorer dialog** — types the file's full path and presses Enter to select it.
- **Click 'Save'** — saves the new Data Set record.
- **Delay (3 sec)** — a fixed pause.
- **Click 'Start Upload'** — this is the button that kicks off the actual Salesforce Apex batch job (background data processing).
- **Delay (2 sec)** — another fixed pause.
- **Keyboard Shortcut (Enter)** — presses Enter to dismiss a confirmation popup that appears.
- **Click 'Data Sets'** — navigates back to the main list, ready for the next file.

This whole 4.2.b sequence repeats for every file, and the outer loop repeats for every group (Contacts group finishes completely before moving to Absence, then Disability — thanks to the sort order from Chapter 2).

---

<a name="chapter-5"></a>
## Chapter 5 — Auto-Login & Email Notification (NEW — built together step by step!)

This whole chapter was added **inside** the "Edge Recently Viewed Data Sets Salesforce" card, as the very FIRST thing that happens — **before** "Click 'New'" (from Chapter 4). It solves the problem where the bot's Salesforce session might be logged out (which used to cause a blank browser tab).

### 5.1 Check App State 'Username'
**Beginner explanation:** This activity looks at the current screen and asks: *"Is there a Username input box visible right now?"* If Salesforce redirected to its login page (because the session expired), this box WILL be visible. If we're already logged in, it WON'T be visible.
- **Wait for:** "Element to appear"
- **Two outcomes (branches):**
  - **"Target appears"** → means we're logged OUT → do the whole login process (5.2 through 5.9 below)
  - **"Target does not appear"** → means we're already logged IN → skip straight to Chapter 4's "Click 'New'"

### 5.2 Read Text File
**Beginner explanation:** Opens and reads the contents of a file called `credentials.json` (which Jay created manually) and stores the raw text inside a variable.
- **File:** `...\RPA Workflow\credentials.json`
- **Output:** `jsonContent` (String)

**What's inside credentials.json:**
```json
{
  "email": "jay.michael.m.tanza@accenture.com.claimconv",
  "password": "Cebu@4826Jay",
  "notificationEmail": "Jay.Tanza@reliancematrix.com"
}
```

### 5.3 Deserialize JSON
**Beginner explanation:** Raw JSON text (from step 5.2) is just a big blob of characters to the computer — this activity actually "parses" it, turning it into a structured object where you can grab individual pieces like `email` or `password` by name.
- **JSON string (input):** `jsonContent`
- **JSON object (output):** `credentialsObject` (Type: `JObject` — a special type from the Newtonsoft.Json library specifically designed to hold parsed JSON data)

### 5.4 Assign — `credEmail`
**Beginner explanation:** Pulls just the "email" piece out of the parsed JSON object.
```vb
credEmail = credentialsObject("email").ToString
```

### 5.5 Assign — `credPassword`
Same idea, but for the password:
```vb
credPassword = credentialsObject("password").ToString
```

### 5.6 Assign — `credNotifyEmail`
Same idea, but for who should receive the notification email:
```vb
credNotifyEmail = credentialsObject("notificationEmail").ToString
```

### 5.7 Type Into 'Username' (Screen 1 of Salesforce login)
- **Target:** the Username input box on the Salesforce login page.
- **Text:** `credEmail`
**Beginner explanation:** Literally types your saved email into that box, just like you would with your keyboard.

### 5.8 Click 'Log In to Sandbox' (1st click)
- **Target:** the blue "Log In to Sandbox" button, captured on Screen 1 (before the password field appears).
**Beginner explanation:** This click causes Salesforce's login page to transition — the Username field greys out, and a NEW Password field appears (Screen 2). This is a two-step login flow.

### 5.9 Type Into 'Password' (Screen 2)
- **Target:** the Password input box (only exists after step 5.8).
- **Text:** `credPassword`

### 5.10 Click 'Log In to Sandbox' (2nd/final click)
- **Target:** the "Log In to Sandbox" button as it appears on Screen 2.
**Beginner explanation:** This actually submits the login attempt. If successful, Salesforce should redirect back toward the original `filterName=__Recent` page.

### 5.11 Use Desktop Outlook App
**Beginner explanation:** This is a "scope" activity — think of it like opening a special toolbox that only works while you're inside it. This particular toolbox connects to whatever Outlook desktop application is ALREADY open and signed in on this computer — no password needed at all, since it just borrows your existing logged-in session.
- **Account:** `Jay.Tanza@reliancematrix.com` (auto-detected)
- **Reference as:** `Outlook` (an internal nickname used by activities inside this scope)

### 5.12 Send Email (inside the "Use Desktop Outlook App" scope)
**Beginner explanation:** Composes and actually sends an email, using the Outlook toolbox opened in step 5.11.
- **Account:** `Outlook` (referring back to step 5.11's scope)
- **To:** `credNotifyEmail`
- **Subject:** `"RPA Bot - Salesforce Successfull!"`
- **Body:** `"The Bot successfully logged into Salesforce and started processing the file upload."`
- **Save as draft:** **Unchecked (False)** — this is critical! If left checked, the email would only be SAVED, never actually SENT.

**Why "Use Desktop Outlook App" instead of other options?**
During building, we explored several alternatives:
| Option Tried | Why It Didn't Work Out (for now) |
|---|---|
| Office 365 "Send Email" (connector) | Needed an Orchestrator-managed connection scoped for Mail — the existing connection was only scoped for OneDrive/SharePoint |
| "Send SMTP Email" (connector version) | Same issue — needed a "ConnectionId" tied to Orchestrator |
| "Send SMTP Email" (classic, Host/Port version) | Needed real email/password credentials for an account with SMTP-sending rights — Jay didn't have separate bot (RPAbottest) credentials, and personal Microsoft passwords can't be "looked up" (modern auth/SSO doesn't expose them) |
| "Use Outlook 365" (with Shared Mailbox field) | Would have worked to send AS "RPAbottest@reliancematrix.com" WITHOUT needing its password — but requires IT to first grant "Send As" delegate permission on that shared mailbox to Jay's account (not yet confirmed/set up) |
| **"Use Desktop Outlook App"** ✅ | **Chosen because it needs ZERO passwords** — just uses whatever Outlook is already open. Trade-off: email comes from Jay's own address, not a dedicated "RPAbottest" bot identity — acceptable for now. |

**Future upgrade path (not yet done):** Once IT either provides real RPAbottest credentials OR grants Jay's account "Send As" permission on the RPAbottest shared mailbox, this can be swapped to send as a proper bot identity instead of Jay's personal account.

### "Target does not appear" branch (from step 5.1)
Left completely empty — if the Username field was never detected in the first place, it means we're already logged in, so there's nothing to do here; the workflow just falls through to Chapter 4's "Click 'New'" directly.

---

<a name="6-variable-glossary"></a>
## Full Variable Glossary (What Each Variable Is For)

| Variable | Type | Purpose |
|---|---|---|
| `in_Environment` | String (input argument) | Tells the bot which Salesforce sandbox to use ("ClaimConv" or "ClaimConv1") |
| `allFiles` | O365DriveRemoteItem[] | Raw list of files fetched from OneDrive |
| `orderedFiles` | List | Files sorted into Contacts → Absence → Disability → others |
| `uploadTypeMap` | Dictionary | Lookup table: filename keyword → Salesforce Upload Type |
| `fileGroups` | Dictionary | Files organized into buckets by category |
| `fileItem` | Object | The current file being processed in the innermost loop |
| `currentGroup` | String | The current category/group name being processed |
| `datasetName1` | String | The name to give the new Salesforce Data Set record (usually the filename) |
| `uploadTypeValue` | String | The specific Upload Type value to select in Salesforce for the current file |
| `strURL` | String | The Salesforce web address to open, based on `in_Environment` |
| `strEnvironment` | String | ⚠️ Declared but never assigned — part of the known bug in the `strURL` logic |
| `jsonContent` | String | Raw text read from `credentials.json` |
| `credentialsObject` | JObject | The parsed/structured version of the JSON credentials |
| `credEmail` | String | Salesforce login email, pulled from the JSON file |
| `credPassword` | String | Salesforce login password, pulled from the JSON file |
| `credNotifyEmail` | String | Who should receive the "login successful" notification email |
| `apexJobId`, `jobStatus`, `allJobsCompleted`, `groupJobIds`, `failedJobMessage` | String / Boolean / List | ⚠️ Declared but NOT yet used — reserved for the still-pending Apex Job completion-check feature (Contacts must finish before Absence, etc.) |

---

<a name="7-known-issues"></a>
## Known Issues & Open Items (Not Yet Fixed)

1. **`strEnvironment` vs `in_Environment` bug** — in the `strURL` Assign step, the "ClaimConv1" branch checks the wrong variable, so it never triggers correctly. Should be changed to check `in_Environment` instead.
2. **Hardcoded download path** (`C:\Users\205tjx\Downloads`) — not portable to other machines/users.
3. **Fixed Delays (3 sec, 2 sec)** — could be replaced with smarter "wait until ready" checks for reliability/speed.
4. **Apex Job sequencing (PM's original request)** — Contacts group should fully finish its Salesforce background processing (checked via Apex Job "Completed" status) before Absence starts, and Absence before Disability. The variables for this (`apexJobId`, `jobStatus`, `allJobsCompleted`, `groupJobIds`, `failedJobMessage`) already exist but aren't wired into any logic yet.
5. **Email sender identity** — currently sends notification as Jay's personal account, not a dedicated bot account (RPAbottest), pending IT permission setup or real bot credentials.
6. **No explicit error handling** around UI interactions — if a button/element isn't found, the bot may crash without a clear, friendly explanation.
7. **No file-type filter** on "Get File or Folder List" — non-CSV files in the source folder would also get picked up.
8. **200-file cap** on file retrieval — could silently skip files if volume grows.

---

*Document generated as a complete reference guide. No changes were made to the actual workflow file while creating this document.*
