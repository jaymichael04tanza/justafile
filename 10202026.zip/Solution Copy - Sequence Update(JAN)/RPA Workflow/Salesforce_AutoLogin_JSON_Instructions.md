# Salesforce Auto-Login Using credentials.json — Very Detailed Step-by-Step Instructions
**Workflow:** Main.xaml — RPA Workflow
**Target Activity:** `NApplicationCard_5` ("Edge Recently Viewed Data Sets Salesforce")
**Prepared for:** Jay Michael Tanza
**Status:** ⚠️ Advisory / planning document only — no changes have been made to the workflow.

---

## 0. What We Already Have

✅ **`credentials.json`** — already created at:
```
C:\Users\205tjx\Downloads\UIPathProjects\OneDrive_2026-09-04\Solution Copy - Sequence Update(JAN)\RPA Workflow\credentials.json
```
Contents:
```json
{
  "email": "jay.michael.m.tanza@accenture.com.claimconv",
  "password": "Cebu@4826Jay"
}
```

✅ **Confirmed login flow behavior** (based on your screenshots) — this is a **TWO-STEP** login, not a single-screen login:

| Screen | What's visible | What you do |
|---|---|---|
| **Screen 1** | Only the **Username** field + **"Log In to Sandbox"** button | Type email → Click **"Log In to Sandbox"** |
| **Screen 2** | Username field (now shows your email, greyed/locked) + a **new Password** field appears + **"Log In to Sandbox"** button again | Type password → Click **"Log In to Sandbox"** again |

This is important — it means you need **two separate "Type Into" + "Click" pairs**, not just one.

---

## 1. Where to Add Everything (Big Picture)

Everything below goes **inside** the `NApplicationCard_5` activity (currently selected in your Studio — "Edge Recently Viewed Data Sets Salesforce"), specifically inside its **Body**, as the **very first activities**, before the existing "Click 'New'" step.

```
Edge Recently Viewed Data Sets Salesforce (NApplicationCard_5)
  └── Body:
        🎯 [NEW] Check Element Exists → isLoginPageVisible
        🎯 [NEW] If isLoginPageVisible
              └── Then:
                    🎯 [NEW] Read Text File → jsonContent
                    🎯 [NEW] Deserialize JSON → credentialsObject
                    🎯 [NEW] Assign → credEmail
                    🎯 [NEW] Assign → credPassword
                    🎯 [NEW] Type Into 'Username' → credEmail
                    🎯 [NEW] Click 'Log In to Sandbox'  (1st click — after username)
                    🎯 [NEW] Type Into 'Password' → credPassword
                    🎯 [NEW] Click 'Log In to Sandbox'  (2nd click — after password)
              └── Else: (leave empty — already logged in)
        ── Click 'New'                     (existing, untouched)
        ── Type Into 'Data Set Name'       (existing)
        ── ... rest of existing steps      (existing)
```

---

## 2. Very Detailed, Click-by-Click Instructions in Studio

### 🔹 STEP A — Open the Activity You're Working In
1. In Studio, make sure `Main.xaml` is open in the Designer.
2. Scroll/navigate to find `NApplicationCard_5` ("Edge Recently Viewed Data Sets Salesforce") — you're already there since it's your current selection.
3. **Double-click** on it (or click the small **pencil/edit icon** if shown) to open its Body — this shows you the list of activities inside (Click 'New', Type Into 'Data Set Name', etc.)

### 🔹 STEP B — Add "Check Element Exists" (Login Detection)
1. Hover your mouse **above the very first activity** inside the Body (above "Click 'New'").
2. You'll see a **thin horizontal line appear with a small "+" (plus) icon** in the middle of it — this is how UiPath lets you insert a new activity at that exact spot.
3. **Click that "+" icon.**
4. A small search box/popup will appear — type: `Check App/Element Exists` (or simply `Element Exists`)
5. Select it from the list that appears.
6. It will now be inserted at that spot, above "Click 'New'".
7. Click on this new "Check Element Exists" activity to select it, then look at the **Properties panel** on the right side of Studio:
   - **Target** → click the small target/crosshair icon next to the Target field, then click on the **"Username"** field on the actual Salesforce login screen (Screen 1) to capture its selector. (You'll need the Salesforce login page open in a browser at that moment to point-and-click it.)
   - **Exists** (Output/Result) → click the field, type a new variable name: `isLoginPageVisible` → press Enter (Studio will auto-create this as a Boolean variable).

### 🔹 STEP C — Add the "If" Condition
1. Hover **right below** the "Check Element Exists" activity you just added — you'll see the same "+" icon appear.
2. Click it, search for `If`, and select the **If** activity.
3. In the **Condition** field at the top of the If activity, type:
   ```
   isLoginPageVisible
   ```
4. You'll now see two empty boxes: **Then** (left/top) and **Else** (right/bottom).

### 🔹 STEP D — Inside the "Then" Box: Add "Read Text File"
1. Click **inside the "Then" box** to make it active.
2. You'll see a placeholder like "Drop activity here" — either:
   - Drag the **"Read Text File"** activity from the Activities panel (search it in the search bar at the top of the Activities panel on the left), and drop it inside the Then box, **OR**
   - Click inside the Then box, then use the search/"+" method the same way as before.
3. Once placed, select it and set its Properties:
   - **FileName** → type or browse to:
     ```
     C:\Users\205tjx\Downloads\UIPathProjects\OneDrive_2026-09-04\Solution Copy - Sequence Update(JAN)\RPA Workflow\credentials.json
     ```
   - **Content** (Output) → type a new variable name: `jsonContent` → press Enter.

### 🔹 STEP E — Add "Deserialize JSON" (right after Read Text File, still inside Then)
1. Hover just below "Read Text File" (still inside the Then box) — the "+" icon will appear again.
2. Click it, search: `Deserialize JSON`
3. Select it, then set its Properties:
   - **JsonString** → type: `jsonContent`
   - **JsonObject** (Output) → type a new variable name: `credentialsObject` → press Enter.

### 🔹 STEP F — Add Two "Assign" Activities (extract email & password)
1. Below "Deserialize JSON", click the "+" icon, search: `Assign`, add it.
2. Configure:
   - **To** (left box): type `credEmail` → press Enter (creates a new String variable)
   - **Value** (right box): type:
     ```
     credentialsObject("email").ToString
     ```
3. Add a **second Assign** right below it the same way:
   - **To:** `credPassword`
   - **Value:**
     ```
     credentialsObject("password").ToString
     ```

### 🔹 STEP G — Add "Type Into 'Username'" (Screen 1)
1. Below the two Assign activities, click "+", search: `Type Into`, add it.
2. Rename it (optional, for clarity) by clicking the activity's display name field and typing: `Type Into 'Username'`
3. Set its **Target**: click the crosshair/target icon, then click on the **Username field** on the live Salesforce login screen (Screen 1 — the one showing only Username + "Log In to Sandbox").
4. Set its **Text** property to:
   ```
   credEmail
   ```

### 🔹 STEP H — Add "Click 'Log In to Sandbox'" (1st time — after typing username)
1. Below "Type Into 'Username'", click "+", search: `Click`, add it.
2. Rename it: `Click 'Log In to Sandbox' (Username step)`
3. Set its **Target**: click the crosshair icon, then click on the blue **"Log In to Sandbox"** button on Screen 1.
4. Leave other settings default (Click Type: Single, Mouse Button: Left).

📌 **What happens next:** After this click, Salesforce will transition to **Screen 2**, showing the Password field.

### 🔹 STEP I — Add "Type Into 'Password'" (Screen 2)
1. Below the click you just added, click "+", search: `Type Into`, add it.
2. Rename it: `Type Into 'Password'`
3. Set its **Target**: click the crosshair icon, then click on the **Password field** — but here's the tricky part: since the Password field only appears **after** clicking "Log In to Sandbox" the first time, you'll need to:
   - Manually navigate to that exact screen in your browser first (type username, click the button once, so Screen 2 is showing), **then** use the target-picker to click on the now-visible Password field.
4. Set its **Text** property to:
   ```
   credPassword
   ```

### 🔹 STEP J — Add "Click 'Log In to Sandbox'" (2nd time — after typing password)
1. Below "Type Into 'Password'", click "+", search: `Click`, add it.
2. Rename it: `Click 'Log In to Sandbox' (Password step)`
3. Set its **Target**: click the crosshair icon, then click on the "Log In to Sandbox" button as it appears on Screen 2 (it will still be visually in roughly the same spot, but make sure you're capturing it on Screen 2 so the selector matches that page state).

### 🔹 STEP K — Leave "Else" Empty
- The **Else** box of your If activity (Step C) should remain empty — if the Username field wasn't detected, it means the user is already logged in, so nothing needs to happen there.

---

## 3. Final Structure Recap (What You Should See in Studio After Adding Everything)

```
Edge Recently Viewed Data Sets Salesforce (NApplicationCard_5)
  └── Body:
        Check Element Exists (Username field) → isLoginPageVisible
        If isLoginPageVisible
          └── Then:
                Read Text File (credentials.json) → jsonContent
                Deserialize JSON (jsonContent) → credentialsObject
                Assign → credEmail = credentialsObject("email").ToString
                Assign → credPassword = credentialsObject("password").ToString
                Type Into 'Username' → Text = credEmail
                Click 'Log In to Sandbox' (Username step)
                Type Into 'Password' → Text = credPassword
                Click 'Log In to Sandbox' (Password step)
          └── Else: (empty)
        Click 'New'                     ← existing, continues as normal after login
        Type Into 'Data Set Name'       ← existing
        Type Into 'Upload Type'         ← existing
        Click 'File' ...                ← existing
        Click 'Save'                    ← existing
        Click 'Start Upload'            ← existing
        Click 'Data Sets'               ← existing
```

---

## 4. Things to Double-Check While Building This

1. **Selector stability for the Password field** — since it only appears after the first click, make sure you capture its selector at the right moment (Screen 2 visible), otherwise Studio might fail to find it later.
2. **Wait for page transition** — you may want to add a short **Delay** or a **"Wait for Ready"** setting between Step H (1st click) and Step I (typing password), since Screen 2 needs a moment to render after clicking "Log In to Sandbox" the first time.
3. **After the 2nd "Log In to Sandbox" click** — Salesforce should then redirect automatically to your original `strURL` (the `filterName=__Recent` page). If it instead lands on a generic homepage, you may need one more **Navigate Browser** step to explicitly go back to `strURL`.
4. **Security reminder** — `credentials.json` currently has the password in plain, unencrypted text. This works for testing, but for production use, migrating to an **Orchestrator Credential Asset** is strongly recommended so the password isn't sitting as plain text on the machine.

---

*This document is for reference/planning only. No edits have been made to Main.xaml or any other project files.*
