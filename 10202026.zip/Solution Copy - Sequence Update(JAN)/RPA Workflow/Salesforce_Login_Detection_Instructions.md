# Salesforce Login Detection & Auto-Login — Implementation Instructions
**Workflow:** Main.xaml — RPA Workflow
**Target Activity:** `NApplicationCard_5` ("Edge Recently Viewed Data Sets Salesforce")
**Prepared for:** Jay Michael Tanza
**Status:** ⚠️ Advisory only — no changes have been made to the workflow. These are instructions for where/how to add the logic yourself (or have it added later).

---

## 1. Problem Being Solved

When the workflow opens Edge and navigates to `strURL`
(e.g. `https://rsl-matrix--claimconv.sandbox.lightning.force.com/lightning/o/cvup2__DataSet__c/list?filterName=__Recent`),
**if the Salesforce session has expired or the user was never logged in**, Salesforce automatically redirects to the login page instead:

```
https://rsl-matrix--claimconv.sandbox.my.salesforce.com/
```

The workflow currently has **no logic to detect or handle this** — it just proceeds straight to "Click 'New'", which would fail because that button doesn't exist on the login page.

---

## 2. Exact Location to Add the New Logic

Inside the activity:
```
Edge Recently Viewed Data Sets Salesforce  (NApplicationCard_5)
  └── Body
```

Insert the new steps as the **very first activities** in that Body, **before** the existing "Click 'New'" activity:

```
Edge Recently Viewed Data Sets Salesforce (NApplicationCard_5)
  └── Body:
        🎯 NEW STEP 1: Check Element Exists (Username field)
        🎯 NEW STEP 2: If (isLoginPageVisible)
              ├── Then: [Login sequence — see section 3]
              └── Else: (leave empty — already logged in)
        ── Click 'New'                     (existing, untouched)
        ── Type Into 'Data Set Name'       (existing)
        ── Type Into 'Upload Type'         (existing)
        ── ... rest of existing steps      (existing)
```

### Why this placement works
`NApplicationCard_5` already navigates to `strURL` via its `Url="[strURL]"` property. If the session is expired, Salesforce redirects to the login page automatically — so checking for the Username field as the *first* thing inside this card's Body catches that redirect before any of the existing Data Set creation steps run.

---

## 3. Detailed Steps for the New Logic

### STEP 1 — `Check App/Element Exists`
- **Purpose:** Detect whether the login page (Username field) is currently visible.
- **Target element:** The **"Username"** input box shown on the `rsl-matrix--claimconv.sandbox.my.salesforce.com` login page.
- **New variable to create:** `isLoginPageVisible` (Boolean)
- This activity only *checks* — it does not click or type anything.

### STEP 2 — `If isLoginPageVisible`

**Then branch (user is logged out → perform login):**
1. **Type Into 'Username'**
   - Target: the Username field from the login page.
   - Value: Salesforce username.
   - ⚠️ Recommended: pull this from an **Orchestrator Credential Asset**, not hardcoded in the workflow.
2. **Click 'Log In to Sandbox'**
   - Target: the blue "Log In to Sandbox" button.
   - Note: Depending on your org's login flow, the **Password** field may appear on this same screen or only after clicking past the Username step. Verify manually first — you may need an additional **Type Into 'Password'** + **Click 'Log In to Sandbox'** step if Salesforce splits it into two screens.
3. **Wait For Ready / Delay**
   - Give Salesforce a moment to authenticate and redirect.

**Else branch (user is already logged in):**
- Leave empty — nothing needs to happen; flow continues to "Click 'New'" as normal.

---

## 4. Important Verification Before Adding This

⚠️ **Please confirm manually first:** After a successful login, does Salesforce automatically redirect back to the original `filterName=__Recent` URL, or does it land on a generic Salesforce homepage instead?
- If it **redirects back automatically** → no extra step needed.
- If it **lands on a generic homepage** → you'll need to add an explicit **Navigate Browser** step after login to go back to `strURL`.

---

## 5. Security Note

Never hardcode the Salesforce username/password directly into the workflow XAML. Use an **Orchestrator Asset (Credential type)** so credentials are centrally managed, encrypted, and not exposed in plain text in the automation.

---

## 6. Quick Reference — Where This Sits in the Overall Workflow

```
For Each currentGroup (loops through fileGroups)
  └── For Each fileItem (loops through files in that group)
        └── Sequence "Body"
              ├── Download File
              ├── Assign (datasetName1, uploadTypeValue)
              ├── Assign (strURL)
              └── Edge Recently Viewed Data Sets Salesforce (NApplicationCard_5)
                    └── Body:
                          🎯 [NEW] Check Element Exists → isLoginPageVisible
                          🎯 [NEW] If isLoginPageVisible → Then: Login sequence / Else: (empty)
                          ── Click 'New'
                          ── Type Into 'Data Set Name'
                          ── Type Into 'Upload Type'
                          ── Click 'File' ...
                          ── Click 'Save'
                          ── Click 'Start Upload'
                          ── Click 'Data Sets'
```

---

*This document is for reference/planning only. No edits have been made to Main.xaml.*
